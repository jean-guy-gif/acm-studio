import Link from 'next/link';

import { backLink, kickerLabel, pageSubtitle, pageTitle } from '@/components/ui/styles';
import { BrandingForm } from '@/features/branding/components/branding-form';
import { getAgencyBranding } from '@/features/branding/queries/get-agency-branding';
import { isManagerRole } from '@/features/team/services/role';
import { getAgency } from '@/lib/auth/get-agency';
import { getProfile } from '@/lib/auth/get-profile';

// Mission 55 jalon 1 — L'identité de l'agence. L'agence règle son logo et sa couleur ; la
// charte s'applique à tout l'outil, et l'aperçu montre le Live tel que le vendeur le verra.
export default async function AgencyIdentityPage() {
  const branding = await getAgencyBranding();
  const profile = await getProfile();
  const agency = profile ? await getAgency(profile.agency_id) : null;

  return (
    <div className="flex flex-col gap-6 md:gap-8">
      <div className="flex flex-col gap-2">
        <Link href="/admin" className={backLink}>
          ← Administration
        </Link>
        <span className={kickerLabel}>Agence</span>
        <h1 className={pageTitle}>Identité de l’agence</h1>
        <p className={pageSubtitle}>
          Votre logo, votre couleur et votre police de marque, appliqués à tout l’outil — jusqu’au
          Live que voit le vendeur.
        </p>
      </div>

      <BrandingForm
        initialPrimary={branding?.brand ?? '#3ea9ff'}
        initialLogoLightUrl={branding?.logoLightUrl ?? null}
        initialLogoDarkUrl={branding?.logoDarkUrl ?? null}
        initialFont={branding?.fontFamily ?? ''}
        initialSiteUrl={branding?.siteUrl ?? ''}
        initialPostalAddress={branding?.postalAddress ?? ''}
        initialProfessionalCard={branding?.professionalCard ?? ''}
        initialProfessionalCardIssuer={branding?.professionalCardIssuer ?? ''}
        initialFinancialGuarantee={branding?.financialGuarantee ?? ''}
        initialDocumentName={branding?.documentName ?? ''}
        agencyName={agency?.name ?? ''}
        // Mission 88 — un conseiller (ou un membre retiré) voit l'identité, sans la modifier.
        readOnly={!profile || Boolean(profile.removed_at) || !isManagerRole(profile.role)}
      />
    </div>
  );
}
