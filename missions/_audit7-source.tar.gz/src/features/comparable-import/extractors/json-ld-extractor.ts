import type { PartialListingData } from '@/features/comparable-import/types';
import { normalizeArea } from '@/features/comparable-import/utils/normalize-area';
import { normalizeCount } from '@/features/comparable-import/utils/normalize-count';
import { normalizePrice } from '@/features/comparable-import/utils/normalize-price';

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function asString(value: unknown): string | null {
  return typeof value === 'string' && value.trim() !== '' ? value.trim() : null;
}

// Keys under which real listing / gallery nodes are commonly nested.
const NESTED_NODE_KEYS = [
  '@graph',
  'itemListElement',
  'item',
  'hasPart',
  'mainEntity',
  'associatedMedia',
];

// Nodes that describe the PORTAL / page chrome, never the property itself.
// A node whose every @type is in this set must not contribute any field or
// image: e.g. an Organization carries the AGENCY's address ("Paris") and logo,
// which must never become the listing's city or photo.
const NON_LISTING_TYPES = new Set([
  'Organization',
  'NewsMediaOrganization',
  'WebSite',
  'BreadcrumbList',
  'ListItem',
  'SearchAction',
  'ContactPoint',
  'Person',
  'RealEstateAgent',
  'LocalBusiness',
  'Review',
  'AggregateRating',
  'FAQPage',
  'Question',
  'Answer',
]);

// True when the node is portal chrome (all of its declared types are
// non-listing types). A node without @type is kept: many portals omit it.
function isNonListingNode(node: Record<string, unknown>): boolean {
  const type = node['@type'];
  const types = Array.isArray(type) ? type : typeof type === 'string' ? [type] : [];
  if (types.length === 0) {
    return false;
  }
  return types.every((t) => typeof t === 'string' && NON_LISTING_TYPES.has(t));
}

function collectNodes(root: unknown, out: Record<string, unknown>[]): void {
  if (Array.isArray(root)) {
    for (const item of root) {
      collectNodes(item, out);
    }
    return;
  }
  if (isRecord(root)) {
    out.push(root);
    for (const key of NESTED_NODE_KEYS) {
      if (key in root) {
        collectNodes(root[key], out);
      }
    }
  }
}

// Resolves the price of ONE node, across the shapes portals actually publish.
// Terrain (staging, 18/08) : Bien’ici décrit le bien dans un nœud
// « Accommodation » SANS prix, et le prix dans un second nœud « Product » dont
// l’offre porte la valeur sous « priceSpecification ». On lit donc, dans
// l’ordre : offers.price, offers.lowPrice, offers.priceSpecification.(price |
// minPrice), puis, à défaut d’offre, les mêmes clés sur le nœud lui-même.
function resolveNodePrice(node: Record<string, unknown>): number | null {
  const offers = node.offers;
  const offerNodes: Record<string, unknown>[] = [];
  if (Array.isArray(offers)) {
    offerNodes.push(...offers.filter(isRecord));
  } else if (isRecord(offers)) {
    offerNodes.push(offers);
    // AggregateOffer wrapping individual Offer nodes.
    const nested = offers.offers;
    if (Array.isArray(nested)) {
      offerNodes.push(...nested.filter(isRecord));
    } else if (isRecord(nested)) {
      offerNodes.push(nested);
    }
  }

  const candidates: unknown[] = [];
  for (const offer of offerNodes) {
    candidates.push(offer.price, offer.lowPrice);
    const specification = offer.priceSpecification;
    const specifications = Array.isArray(specification)
      ? specification.filter(isRecord)
      : isRecord(specification)
        ? [specification]
        : [];
    for (const spec of specifications) {
      candidates.push(spec.price, spec.minPrice);
    }
  }
  // No offer node at all: the price may sit directly on the node.
  if (offerNodes.length === 0) {
    candidates.push(node.price);
    const specification = node.priceSpecification;
    if (isRecord(specification)) {
      candidates.push(specification.price, specification.minPrice);
    }
  }

  for (const candidate of candidates) {
    const price = normalizePrice(candidate);
    if (price != null) {
      return price;
    }
  }
  return null;
}

function collectImages(image: unknown, out: string[]): void {
  if (typeof image === 'string') {
    if (image.trim() !== '') {
      out.push(image.trim());
    }
    return;
  }
  if (Array.isArray(image)) {
    for (const item of image) {
      collectImages(item, out);
    }
    return;
  }
  if (isRecord(image)) {
    const url = asString(image.url) ?? asString(image.contentUrl);
    if (url) {
      out.push(url);
    }
  }
}

// Extracts partial listing data from all <script type="application/ld+json">
// blocks. Everything is treated as unknown; invalid JSON blocks are skipped and
// never fail the whole import.
export function extractJsonLd(html: string): PartialListingData {
  const result: PartialListingData = {};
  const photos: string[] = [];
  const features: string[] = [];
  const nodes: Record<string, unknown>[] = [];

  const blockRegex = /<script[^>]*type=["']application\/ld\+json["'][^>]*>([\s\S]*?)<\/script>/gi;
  let block: RegExpExecArray | null;
  while ((block = blockRegex.exec(html)) !== null) {
    let parsed: unknown;
    try {
      parsed = JSON.parse(block[1].trim());
    } catch {
      continue;
    }
    collectNodes(parsed, nodes);
  }

  for (const node of nodes) {
    if (isNonListingNode(node)) {
      continue;
    }
    if (result.title == null) {
      const title = asString(node.name) ?? asString(node.title);
      if (title) {
        result.title = title;
      }
    }
    if (result.listingDescription == null) {
      const description = asString(node.description);
      if (description) {
        result.listingDescription = description;
      }
    }
    if (result.price == null) {
      const price = resolveNodePrice(node);
      if (price != null) {
        result.price = price;
      }
    }
    const address = isRecord(node.address) ? node.address : null;
    if (address) {
      if (result.address == null) {
        const street = asString(address.streetAddress);
        if (street) {
          result.address = street;
        }
      }
      if (result.postalCode == null) {
        const postal = asString(address.postalCode);
        if (postal) {
          result.postalCode = postal;
        }
      }
      if (result.city == null) {
        const city = asString(address.addressLocality);
        if (city) {
          result.city = city;
        }
      }
    }
    if (result.surfaceArea == null) {
      const floor = node.floorSize ?? node.size;
      const raw = isRecord(floor) ? floor.value : floor;
      const surface = normalizeArea(raw);
      if (surface != null) {
        result.surfaceArea = surface;
      }
    }
    if (result.roomsCount == null) {
      const rooms = normalizeCount(node.numberOfRooms);
      if (rooms != null) {
        result.roomsCount = rooms;
      }
    }
    if (result.bedroomsCount == null) {
      const bedrooms = normalizeCount(node.numberOfBedrooms ?? node.numberOfBedroomsTotal);
      if (bedrooms != null) {
        result.bedroomsCount = bedrooms;
      }
    }
    if (result.bathroomsCount == null) {
      const bathrooms = normalizeCount(node.numberOfBathroomsTotal ?? node.numberOfBathrooms);
      if (bathrooms != null) {
        result.bathroomsCount = bathrooms;
      }
    }
    if (result.energyRating == null) {
      const energy =
        asString(node.energyEfficiencyCategory) ??
        (isRecord(node.hasEnergyEfficiencyCategory)
          ? asString(node.hasEnergyEfficiencyCategory.name)
          : null);
      if (energy) {
        result.energyRating = energy;
      }
    }
    if (result.constructionYear == null) {
      const rawYear =
        typeof node.yearBuilt === 'number' ? node.yearBuilt : Number(asString(node.yearBuilt));
      if (Number.isInteger(rawYear) && rawYear > 1000 && rawYear < 3000) {
        result.constructionYear = rawYear;
      }
    }
    const amenities = node.amenityFeature;
    if (Array.isArray(amenities)) {
      for (const amenity of amenities) {
        if (isRecord(amenity)) {
          const name = asString(amenity.name);
          if (name) {
            features.push(name);
          }
        }
      }
    }
    // Images can live under several keys depending on the schema. A bare `url` is
    // only treated as an image on an ImageObject node (never the listing page URL).
    const type = node['@type'];
    const isImageObject =
      type === 'ImageObject' || (Array.isArray(type) && type.includes('ImageObject'));
    const imageKeys = [
      'image',
      'photo',
      'photos',
      'images',
      'gallery',
      'thumbnailUrl',
      'contentUrl',
    ];
    if (isImageObject) {
      imageKeys.push('url');
    }
    for (const key of imageKeys) {
      collectImages(node[key], photos);
    }
  }

  if (photos.length > 0) {
    result.photoUrls = photos;
  }
  if (features.length > 0) {
    result.listingFeatures = features;
  }
  return result;
}
