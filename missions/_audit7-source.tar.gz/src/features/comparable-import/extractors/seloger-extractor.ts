import type { PartialListingData } from '@/features/comparable-import/types';
import { decodeHtmlEntities } from '@/features/comparable-import/utils/html-text';
import { normalizeArea } from '@/features/comparable-import/utils/normalize-area';
import {
  normalizeCount,
  studioRoomsCount,
} from '@/features/comparable-import/utils/normalize-count';
import { normalizePrice } from '@/features/comparable-import/utils/normalize-price';

const DOMAIN = 'seloger.com';

export function isSeLoger(hostname: string): boolean {
  const host = hostname.toLowerCase();
  return host === DOMAIN || host.endsWith(`.${DOMAIN}`);
}

function firstMatch(input: string, regex: RegExp): string | null {
  const match = input.match(regex);
  return match ? match[1] : null;
}

// "l-estagnol" -> "L'Estagnol", "antibes" -> "Antibes".
function toLabel(slug: string): string {
  return slug
    .replace(/^([ld])-/i, "$1'")
    .split('-')
    .map((word) => (word === '' ? word : word.charAt(0).toUpperCase() + word.slice(1)))
    .join(' ')
    .replace(/(['’])([a-zà-ÿ])/g, (_, apostrophe, char) => apostrophe + char.toUpperCase());
}

// Les données de la page sont des chaînes JSON imbriquées : les guillemets y
// arrivent échappés (`\\"city\\":\\"Antibes\\"`). On aplatit avant de lire, sinon
// aucun motif ne correspond.
function flattenQuotes(html: string): string {
  return html.replace(/\\+"/g, '"');
}

// Valeur unique d'un motif, ou null s'il y en a zéro ou plusieurs. Sert à ne
// retenir une donnée que lorsqu'elle n'est pas ambiguë.
function onlyValue(html: string, pattern: RegExp): string | null {
  const values = new Set<string>();
  for (const match of html.matchAll(pattern)) {
    const value = match[1].trim();
    if (value !== '') {
      values.add(value);
    }
  }
  return values.size === 1 ? [...values][0] : null;
}

// Mission 49 — les photos de l'annonce, lues dans la CHARGE D'HYDRATATION (SeLoger
// est une SPA Next), pas dans le DOM rendu. Le nœud du bien porte
// `"medias":{"images":[{ "url": "https://mms.seloger.com/…" }, …]}` : c'est le
// tableau AUTORITAIRE (les URLs sont des UUID opaques, sans clé d'annonce, donc
// aucun autre critère ne les distingue). Position-indépendant : marche que la galerie
// soit rendue en haut, en bas, ou pas du tout. Sur une page avec des similaires
// rendus, plusieurs tableaux coexistent — on retient CELUI dont le nœud porte la
// référence de NOTRE annonce (la clé de l'URL). Aucun tableau rattachable → aucune
// photo (fail-closed), jamais celle d'un voisin.
function listingPhotosFromHydration(flat: string, listingKey: string | null): string[] {
  const blocks = [...flat.matchAll(/"medias"\s*:\s*\{\s*"images"\s*:\s*(\[[\s\S]*?\])/g)];
  if (blocks.length === 0) {
    return [];
  }
  let chosen: RegExpMatchArray | null = null;
  if (listingKey) {
    chosen =
      blocks.find(
        (block) =>
          block.index != null &&
          flat.slice(Math.max(0, block.index - 800), block.index).includes(listingKey),
      ) ?? null;
  }
  if (!chosen && blocks.length === 1) {
    chosen = blocks[0];
  }
  if (!chosen) {
    return []; // plusieurs annonces, aucune rattachée à notre clé → rien, pas un voisin
  }
  const urls: string[] = [];
  for (const image of chosen[1].matchAll(/"url"\s*:\s*"([^"]+)"/g)) {
    urls.push(image[1]);
  }
  return [...new Set(urls)];
}

// Dernier segment du chemin de l'URL = clé canonique de l'annonce (ex. 26ZEJMLWB13Y).
function listingKeyOf(rawUrl: string | undefined): string | null {
  if (!rawUrl) {
    return null;
  }
  try {
    const segments = new URL(rawUrl).pathname.split('/').filter(Boolean);
    const last = segments[segments.length - 1] ?? '';
    return last.length >= 3 ? last : null;
  } catch {
    return null;
  }
}

// Parses city/district from a SeLoger listing path like ".../antibes-06/l-estagnol/...".
function locationFromUrl(rawUrl: string | undefined): { city?: string; district?: string } {
  if (!rawUrl) {
    return {};
  }
  const match = rawUrl.match(/\/([a-z-]+)-\d{2}\/([a-z'’-]+)\//i);
  if (!match) {
    return {};
  }
  return { city: toLabel(match[1]), district: toLabel(match[2]) };
}

// Classes DPE / GES.
//
// Terrain (19/08) : SeLoger ne les écrit pas en clair dans le HTML lisible, mais
// dans un bloc de données doublement échappé, sous la forme
//   \"efficiencyClass\":{\"index\":1,\"rating\":\"B\"} … \"name\":\"Diagnostic de
//   performance énergétique (DPE)\"
// Le libellé suit la note : on lit donc la note, puis on regarde le texte qui
// suit pour savoir s'il s'agit du DPE ou du GES. Aucune note n'est devinée : en
// l'absence de libellé reconnu, on ne renseigne rien.
function extractEnergyRatings(html: string): { energyRating?: string; gesRating?: string } {
  const result: { energyRating?: string; gesRating?: string } = {};
  const pattern = /rating\\?"\s*:\s*\\?"([A-G])\\?"/gi;
  const WINDOW = 600;

  for (const match of html.matchAll(pattern)) {
    const rating = match[1].toUpperCase();
    const from = (match.index ?? 0) + match[0].length;
    const following = stripAccents(html.slice(from, from + WINDOW)).toLowerCase();

    // On retient le libellé le PLUS PROCHE, pas le premier trouvé au hasard :
    // les deux blocs (DPE puis GES) se suivent dans la page, et une fenêtre
    // large voit les deux.
    const gesAt = firstIndexOf(following, ['gaz a effet de serre', 'ges']);
    const dpeAt = firstIndexOf(following, ['performance energetique', 'dpe']);
    if (gesAt == null && dpeAt == null) {
      continue;
    }
    if (dpeAt == null || (gesAt != null && gesAt < dpeAt)) {
      result.gesRating ??= rating;
    } else {
      result.energyRating ??= rating;
    }
  }
  return result;
}

// Position du premier marqueur trouvé, ou null si aucun.
function firstIndexOf(haystack: string, needles: readonly string[]): number | null {
  let best: number | null = null;
  for (const needle of needles) {
    const at = haystack.indexOf(needle);
    if (at !== -1 && (best == null || at < best)) {
      best = at;
    }
  }
  return best;
}

function stripAccents(value: string): string {
  return value.normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

// SeLoger exposes the key data in og:title ("... T3/F3 52 m² 303000 € ...").
// City/district come from the ORIGINAL advisor URL (not the redirected canonical
// one). DPE/GES are handled by the strict generic extractors, never here.
export function extractSeLoger(html: string, originalUrl?: string): PartialListingData {
  const result: PartialListingData = {};

  const ogTitleRaw = firstMatch(html, /<meta[^>]+property="og:title"[^>]+content="([^"]+)"/i);
  if (ogTitleRaw) {
    const title = decodeHtmlEntities(ogTitleRaw).trim();
    if (title !== '') {
      result.title = title;
    }
    const price = normalizePrice(firstMatch(title, /([\d][\d\s.]{3,})\s*€/));
    if (price != null) {
      result.price = price;
    }
    const surface = normalizeArea(firstMatch(title, /(\d+(?:[.,]\d+)?)\s*m(?:²|2)/i));
    if (surface != null) {
      result.surfaceArea = surface;
    }
    // Mission 68 — « Studio » sans « T1 » / « F1 » dans le titre = 1 pièce.
    const rooms = normalizeCount(firstMatch(title, /\b[TF](\d+)\b/)) ?? studioRoomsCount(title);
    if (rooms != null) {
      result.roomsCount = rooms;
    }
  }

  // Prefer the original URL; fall back to og:url only if needed.
  const ogUrl = firstMatch(html, /<meta[^>]+property="og:url"[^>]+content="([^"]+)"/i) ?? undefined;
  const location = locationFromUrl(originalUrl).city
    ? locationFromUrl(originalUrl)
    : locationFromUrl(ogUrl);
  if (location.city) {
    result.city = location.city;
  }
  if (location.district) {
    result.district = location.district;
  }

  // Terrain (19/08) : l'adresse déduite du chemin de l'URL ne sort que si le
  // conseiller a collé l'URL longue. La page, elle, porte toujours la commune et
  // le code postal dans ses données. On ne les retient que s'il n'y en a QU'UN
  // de chaque : une page contient aussi l'adresse de l'agence, et confondre les
  // deux placerait le bien dans la mauvaise ville.
  const flat = flattenQuotes(html);
  if (result.city == null) {
    const city = onlyValue(flat, /"city"\s*:\s*"([^"]{2,60})"/gi);
    if (city != null) {
      result.city = city;
    }
  }
  if (result.postalCode == null) {
    const zip = onlyValue(flat, /"(?:zipCode|postalCode)"\s*:\s*"(\d{5})"/gi);
    if (zip != null) {
      result.postalCode = zip;
    }
  }

  const energy = extractEnergyRatings(html);
  if (energy.energyRating) {
    result.energyRating = energy.energyRating;
  }
  if (energy.gesRating) {
    result.gesRating = energy.gesRating;
  }

  // Mission 49 — photos AUTORITAIRES depuis la charge d'hydratation (voir plus haut).
  const photos = listingPhotosFromHydration(flat, listingKeyOf(originalUrl));
  if (photos.length > 0) {
    result.photoUrls = photos;
  }
  // Contrôle du nombre annoncé (« Afficher les 11 photos ») : rend vérifiable un
  // pipeline sans jeton dans les URLs. Écart → journal, jamais un échec silencieux.
  const announced = firstMatch(html, /Afficher\s+les\s+(\d+)\s+photos/i);
  if (announced != null) {
    const expected = Number.parseInt(announced, 10);
    if (Number.isFinite(expected) && photos.length < expected) {
      console.warn(
        `[seloger] ${expected} photos annoncées, ${photos.length} lues dans medias.images` +
          ` (${originalUrl ?? '?'})`,
      );
    }
  }

  return result;
}
