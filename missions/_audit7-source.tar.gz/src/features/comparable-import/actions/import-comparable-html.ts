'use server';

import { FETCH_MESSAGES } from '@/features/comparable-import/services/fetch-listing-page';

import type { ComparableImportResult } from '@/features/comparable-import/types';
import { extractListingData } from '@/features/comparable-import/services/extract-listing-data';
import { normalizeListingData } from '@/features/comparable-import/services/normalize-listing-data';
import { observeListing } from '@/features/comparable-import/services/record-listing-observation';
import { detectSource } from '@/features/comparable-import/utils/detect-source';
import { isAllowedProtocol, normalizeUrl } from '@/features/comparable-import/utils/normalize-url';
import { getProfile } from '@/lib/auth/get-profile';
import { createClient } from '@/lib/supabase/server';

const GENERIC_ERROR = 'L’import a échoué. Vous pouvez saisir le bien manuellement.';

// The listing page read by the extension, in the ADVISOR'S own browser (portals refuse
// the server-side fetch). Nothing is bypassed — this only analyses content the advisor
// can already see. Same extraction pipeline as the URL import; NO remote request
// is ever made by this action. Since Mission 47 it also records a dated market
// observation as a side effect (a fact about the public listing, never a
// comparable row and never tied to a role).
const MAX_HTML_BYTES = 4 * 1024 * 1024;

export async function importComparableHtml(
  projectId: string,
  formData: FormData,
): Promise<ComparableImportResult> {
  const profile = await getProfile();
  if (!profile) {
    return { ok: false, error: GENERIC_ERROR };
  }

  const supabase = await createClient();

  // Multi-tenant guard: the project must belong to the caller's agency.
  const { data: project } = await supabase
    .from('projects')
    .select('id')
    .eq('id', projectId)
    .eq('agency_id', profile.agency_id)
    .maybeSingle();
  if (!project) {
    return { ok: false, error: GENERIC_ERROR };
  }

  // The original listing URL is required: it anchors relative photo URLs,
  // the source label and the stored listing_url.
  const rawUrl = String(formData.get('url') ?? '').trim();
  const url = normalizeUrl(rawUrl);
  if (!url || !isAllowedProtocol(url)) {
    return { ok: false, error: FETCH_MESSAGES.invalid };
  }

  const html = String(formData.get('html') ?? '');
  if (html.trim() === '') {
    return { ok: false, error: 'La page de l’annonce est vide.' };
  }
  if (Buffer.byteLength(html, 'utf8') > MAX_HTML_BYTES) {
    return { ok: false, error: 'La page de l’annonce est trop volumineuse.' };
  }

  const parts = extractListingData(html, url.href);
  const source = detectSource(url.hostname);
  const { data, foundFields, missingFields } = normalizeListingData(parts, url.href, source);

  if (foundFields.length === 0 && data.photoUrls.length === 0) {
    return { ok: false, error: 'Aucune information exploitable n’a été détectée.' };
  }

  // Side effect: record a dated observation of this public listing and derive its
  // history (age, price change). Best effort — never fails the import.
  const history = await observeListing(supabase, profile.agency_id, url.href, data);

  return { ok: true, data, foundFields, missingFields, history };
}
