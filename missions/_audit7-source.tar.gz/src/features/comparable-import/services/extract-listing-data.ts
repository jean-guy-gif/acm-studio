import {
  extractBienIci,
  isBienIci,
} from '@/features/comparable-import/extractors/bienici-extractor';
import { extractFigaro, isFigaro } from '@/features/comparable-import/extractors/figaro-extractor';
import {
  extractGreenAcres,
  isGreenAcres,
} from '@/features/comparable-import/extractors/green-acres-extractor';
import { extractHtml } from '@/features/comparable-import/extractors/html-extractor';
import {
  extractMaisonsEtAppartements,
  isMaisonsEtAppartements,
} from '@/features/comparable-import/extractors/maisons-et-appartements-extractor';
import { extractJsonLd } from '@/features/comparable-import/extractors/json-ld-extractor';
import { extractOpenGraph } from '@/features/comparable-import/extractors/open-graph-extractor';
import {
  extractSeLoger,
  isSeLoger,
} from '@/features/comparable-import/extractors/seloger-extractor';
import { readMarkedMandate } from '@/features/comparable-import/services/read-listing-mandate';
import type { PartialListingData } from '@/features/comparable-import/types';
import { detectSource } from '@/features/comparable-import/utils/detect-source';
import { extractEmbeddedDescription } from '@/features/comparable-import/utils/extract-embedded-description';
import { extractEmbeddedImageUrls } from '@/features/comparable-import/utils/extract-embedded-image-urls';
import { extractListingPublishedAt } from '@/features/comparable-import/utils/extract-listing-published-at';
import { extractVisibleDescription } from '@/features/comparable-import/utils/extract-visible-description';
import { extractVisibleFeatures } from '@/features/comparable-import/utils/extract-visible-features';
import { mainAdvertRegion } from '@/features/comparable-import/utils/main-advert-region';
import type { ListingMandate } from '@/features/competitor-mandate/types';

export type ExtractedParts = {
  portal: PartialListingData;
  jsonLd: PartialListingData;
  openGraph: PartialListingData;
  html: PartialListingData;
  // Adresses d'images trouvées dans le texte de la page hors balises <img>
  // (galeries chargées par script). Volontairement séparées : elles ne sont
  // retenues que si elles proviennent du même hébergeur que les photos déjà
  // identifiées — voir normalize-listing-data.
  embeddedPhotoUrls: string[];
  // Description longue trouvée dans les données de la page (souvent la seule
  // complète : la balise `meta` est tronquée). Voir normalize-listing-data,
  // qui retient la description la plus longue, pas la première.
  embeddedDescription: string | null;
  // Date de première mise en ligne publiée par le portail lui-même
  // (`datePosted` schema.org, `creationDate`…). C'est la source du délai de
  // commercialisation : aucun service tiers n'est interrogé.
  listingPublishedAt: string | null;
  // Texte de l'annonce tel qu'il s'affiche dans la page. Mesuré le 19/08 : la
  // description lue jusqu'ici venait de la balise `meta` et faisait 38
  // caractères sur Green Acres — d'où les caractéristiques jamais cochées.
  visibleDescription: string | null;
  // Liste des caractéristiques telle que le portail l'affiche (« Terrasse »,
  // « Box de stationnement », « Ascenseur »). Elle sortait vide sur les CINQ
  // portails testés : personne ne la lisait.
  visibleFeatures: string[];
  // Mission 83 — ce que la page MARQUE du vendeur et de l'exclusivité (donnée structurée,
  // badge, bloc annonceur). Le titre et la description complètent dans normalize-listing-data.
  mandate?: ListingMandate;
};

// Runs the domain-specific extractor (if any) plus the generic ones. The portal
// extractor has the highest priority in the merge. originalUrl is the URL the
// advisor pasted (used e.g. for SeLoger location, before any canonical redirect).
export function extractListingData(html: string, originalUrl: string): ExtractedParts {
  let hostname = '';
  try {
    hostname = new URL(originalUrl).hostname;
  } catch {
    hostname = '';
  }

  let portal: PartialListingData = {};
  // Mission 80 — sur ces quatre portails, la classe DPE ne vient que de la lettre MARQUÉE que
  // lit l'extracteur du portail. Le lecteur générique (un libellé « DPE » suivi d'une lettre)
  // y lisait l'échelle : « A » sur Green Acres, « D » sur une annonce Figaro classée C.
  let portalReadsDpe = false;
  if (isGreenAcres(hostname)) {
    portal = extractGreenAcres(html, originalUrl);
    portalReadsDpe = true;
  } else if (isSeLoger(hostname)) {
    portal = extractSeLoger(html, originalUrl);
  } else if (isBienIci(hostname)) {
    portal = extractBienIci(html, originalUrl);
    portalReadsDpe = true;
  } else if (isFigaro(hostname)) {
    portal = extractFigaro(html);
    portalReadsDpe = true;
  } else if (isMaisonsEtAppartements(hostname)) {
    portal = extractMaisonsEtAppartements(html);
    portalReadsDpe = true;
  }
  const generic = extractHtml(html);
  if (portalReadsDpe) {
    delete generic.energyRating;
  }

  // Mission 49 — description ET photos se lisent DANS le bloc de l'annonce, jamais
  // sur la page (où les cartes voisines portent la description et les photos d'un
  // autre bien). Les lecteurs génériques ci-dessous sont donc cadrés à cette seule
  // tranche. Pour M&A et les portails inconnus, la tranche est vide : on ne ratisse
  // pas la page — l'extracteur de portail fait foi (§3, le niveau 3 est supprimé).
  const source = detectSource(hostname);
  const region = mainAdvertRegion(html, source);

  return {
    portal,
    jsonLd: extractJsonLd(html),
    openGraph: extractOpenGraph(html),
    html: generic,
    embeddedPhotoUrls: extractEmbeddedImageUrls(region),
    embeddedDescription: extractEmbeddedDescription(region),
    listingPublishedAt: extractListingPublishedAt(html),
    visibleDescription: extractVisibleDescription(region),
    visibleFeatures: extractVisibleFeatures(html),
    mandate: readMarkedMandate(html, source),
  };
}
