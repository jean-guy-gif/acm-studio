// Canonicalises a listing URL BEFORE anything else — before the robots check and
// before the fetch — so we control and retrieve exactly the same address.
//
// Why this exists: a SeLoger link copied from a results page carries tracking
// parameters (?cmp=, ?bd=, ?projects=, ?referrer=, ?page=, ?q=…). SeLoger's
// robots.txt forbids those ADDRESS SHAPES, not the listings — the same listing
// without its query string is allowed (measured). So we strip the query down to the
// parameters that actually IDENTIFY the listing.
//
// Per-portal, based on an EXPLICIT allowlist:
//   - SeLoger and Bien'ici (and the other retained portals) carry the id in the
//     PATH → the allowlist is empty → the whole query string is dropped.
//   - A portal whose id lives in the query would list that one parameter here; every
//     other parameter is dropped.
//   - An UNKNOWN portal is left untouched.
//
// Forbidden by design: stripping parameters until the address passes robots. The
// normalisation is DETERMINISTIC and never depends on the robots result — it is
// always the same. If the canonical address is still refused, it is refused.

type PortalRule = { suffixes: string[]; keepQueryParams: string[] };

const PORTAL_RULES: PortalRule[] = [
  { suffixes: ['seloger.com'], keepQueryParams: [] },
  { suffixes: ['bienici.com'], keepQueryParams: [] },
  { suffixes: ['green-acres.fr'], keepQueryParams: [] },
  { suffixes: ['lefigaro.fr'], keepQueryParams: [] },
  { suffixes: ['maisonsetappartements.fr'], keepQueryParams: [] },
  // leboncoin.fr : NON supporté, ne pas rajouter. Son robots.txt interdit /ad/,
  // le chemin même des annonces — l'import serait refusé au robots-check. Sans
  // règle ici, une adresse leboncoin est traitée comme un portail inconnu
  // (laissée intacte), ce qui est correct puisqu'on ne la lira jamais.
];

function ruleFor(hostname: string): PortalRule | null {
  const host = hostname.toLowerCase();
  return (
    PORTAL_RULES.find((rule) =>
      rule.suffixes.some((suffix) => host === suffix || host.endsWith(`.${suffix}`)),
    ) ?? null
  );
}

// Mission 83 — Green Acres ouvre une annonce PAR-DESSUS la page de recherche : l'adresse copiée
// est alors celle de la recherche, et l'annonce n'y figure que dans `openAdvert`. Retirer la
// requête rendait la page de recherche (« 0 propriétés »), lue comme une annonce. Mesuré le
// 09/10/2026 : l'annonce a son adresse propre, `/fr/properties/<id>.htm`, que le portail redirige
// vers sa fiche (`/fr/properties/immobilier/grasse/<id>.htm`). On ouvre celle-là.
function greenAcresOpenAdvert(url: URL): string | null {
  const host = url.hostname.toLowerCase();
  if (host !== 'green-acres.fr' && !host.endsWith('.green-acres.fr')) {
    return null;
  }
  const id = url.searchParams.get('openAdvert') ?? '';
  return /^[A-Za-z0-9]{8,32}$/.test(id) ? `${url.origin}/fr/properties/${id}.htm` : null;
}

export function normalizeListingUrl(rawUrl: string): string {
  let url: URL;
  try {
    url = new URL(rawUrl);
  } catch {
    return rawUrl;
  }

  const rule = ruleFor(url.hostname);
  if (!rule) {
    return rawUrl; // unknown portal → untouched
  }

  const openAdvert = greenAcresOpenAdvert(url);
  if (openAdvert) {
    return openAdvert;
  }

  const keep = new Set(rule.keepQueryParams);
  const kept = [...url.searchParams.entries()].filter(([name]) => keep.has(name));
  url.search = '';
  for (const [name, value] of kept) {
    url.searchParams.append(name, value);
  }
  url.hash = ''; // a fragment is a UI anchor, never part of the canonical address
  return url.toString();
}

// Mission 108 — UNE adresse par annonce, sur tous les chemins d'import (recherche, adresse
// collée, saisie à la main) : l'adresse lue, puis nettoyée par portail (ci-dessus). C'est elle
// qui est enregistrée, et sur elle que joue l'unicité « une annonce, une fiche ». null : ce
// n'est pas une adresse web.
export function parseListingUrl(raw: string): URL | null {
  const trimmed = raw.trim();
  if (trimmed === '') {
    return null;
  }
  try {
    return new URL(normalizeListingUrl(new URL(trimmed).href));
  } catch {
    return null;
  }
}

// La forme enregistrée : l'adresse nettoyée, ou le texte tel quel s'il n'est pas une adresse
// (une saisie à la main garde ce que le conseiller a écrit).
export function storedListingUrl(raw: string | null | undefined): string | null {
  const trimmed = raw?.trim() ?? '';
  if (trimmed === '') {
    return null;
  }
  return parseListingUrl(trimmed)?.href ?? trimmed;
}
