import { describe, expect, it } from 'vitest';

import { normalizeListingUrl } from '@/features/comparable-import/utils/normalize-listing-url';

describe('normalizeListingUrl — one case per portal (real address shapes)', () => {
  it('SeLoger : id dans le chemin → toute la requête tombe', () => {
    expect(
      normalizeListingUrl(
        'https://www.seloger.com/annonces/achat/appartement/villeneuve-loubet-06270/26ZEJMLWB13Y?projects=2&cmp=abc',
      ),
    ).toBe(
      'https://www.seloger.com/annonces/achat/appartement/villeneuve-loubet-06270/26ZEJMLWB13Y',
    );
  });

  it('SeLoger : un « ? » de fin sans paramètre est retiré', () => {
    expect(
      normalizeListingUrl(
        'https://www.seloger.com/annonces/.../villeneuve-loubet-06270/26ZEJMLWB13Y?',
      ),
    ).toBe('https://www.seloger.com/annonces/.../villeneuve-loubet-06270/26ZEJMLWB13Y');
  });

  it('Bien’ici : id dans le chemin → le ?q= de recherche tombe', () => {
    expect(
      normalizeListingUrl(
        'https://www.bienici.com/annonce/vente/villeneuve-loubet/appartement/3pieces/apimo-85508663?q=%2Frecherche%2Fachat',
      ),
    ).toBe(
      'https://www.bienici.com/annonce/vente/villeneuve-loubet/appartement/3pieces/apimo-85508663',
    );
  });

  it('Green-Acres : annonce ouverte par-dessus une recherche (openAdvert) → son adresse propre', () => {
    expect(
      normalizeListingUrl(
        'https://www.green-acres.fr/maison-a-vendre?searchQuery=cn-fr-lg-fr-city_id-city_7123-type-properties-mn_p-310000-mx_p-380000-mn_beds-3&openAdvert=Aw85w5p55r5k79fd',
      ),
    ).toBe('https://www.green-acres.fr/fr/properties/Aw85w5p55r5k79fd.htm');
  });

  it('Green-Acres : un openAdvert qui n’est pas un identifiant est ignoré', () => {
    expect(
      normalizeListingUrl('https://www.green-acres.fr/maison-a-vendre?openAdvert=../../admin'),
    ).toBe('https://www.green-acres.fr/maison-a-vendre');
  });

  it('Green-Acres : requête de suivi retirée', () => {
    expect(
      normalizeListingUrl('https://www.green-acres.fr/en/properties/12345.htm?utm_source=results'),
    ).toBe('https://www.green-acres.fr/en/properties/12345.htm');
  });

  it('Figaro Immobilier : requête de suivi retirée', () => {
    expect(
      normalizeListingUrl('https://immobilier.lefigaro.fr/annonces/annonce-12345.html?cmp=xyz'),
    ).toBe('https://immobilier.lefigaro.fr/annonces/annonce-12345.html');
  });

  it('Maisons et Appartements : requête de suivi retirée', () => {
    expect(
      normalizeListingUrl(
        'https://www.maisonsetappartements.fr/fr/06/annonce-vente-appartement-nice-12345.html?referrer=y',
      ),
    ).toBe('https://www.maisonsetappartements.fr/fr/06/annonce-vente-appartement-nice-12345.html');
  });

  // leboncoin.fr n'est plus un portail supporté (robots.txt interdit /ad/) : il
  // tombe désormais dans « portail inconnu → adresse inchangée » ci-dessous.

  it('portail inconnu → adresse inchangée', () => {
    const url = 'https://portail-inconnu.example/annonce/42?ref=abc&page=2';
    expect(normalizeListingUrl(url)).toBe(url);
  });

  it('adresse invalide → renvoyée telle quelle', () => {
    expect(normalizeListingUrl('pas une url')).toBe('pas une url');
  });
});
