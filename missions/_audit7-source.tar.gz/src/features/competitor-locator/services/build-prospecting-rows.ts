import { displayCommune } from '@/features/competitor-search/utils/arrondissements';
import { deriveListingAge } from '@/features/comparable-import/services/derive-listing-age';
import { derivePriceChange } from '@/features/comparable-import/services/derive-price-change';
import type { ListingAge } from '@/features/comparable-import/types';
import {
  LISTING_PORTAL_LABELS,
  extractListingKey,
} from '@/features/comparable-import/utils/extract-listing-key';
import type { Comparable } from '@/features/comparables/types';
import {
  canAcceptProposedAddress,
  confirmedByAdvisor,
} from '@/features/competitor-locator/services/advisor-address';
import {
  prospectingStep,
  type ProspectingStep,
} from '@/features/competitor-mandate/services/mandate-columns';
import {
  NO_OPPOSITIONS,
  opposedOn,
  type Oppositions,
} from '@/features/prospecting/services/opposition';
import {
  prospectingStatus,
  type ProspectingStatus,
} from '@/features/prospecting/services/prospecting-status';
import { formatEuro, formatPercent } from '@/lib/format';

// Mission 75 — « Concurrents à prospecter » : la liste de tournée d'un dossier conclu « mandat
// signé ». Pure : chaque ligne est composée de ce qu'ACM sait déjà (annonce, observations,
// Localisateur). Rien n'est inventé : un champ absent reste absent.

// La section n'existe que pour un dossier en Suivi dont l'issue est « mandat signé ».
export function isProspectingOpen(status: string, outcome: string | null | undefined): boolean {
  return status === 'meeting_completed' && outcome === 'signed';
}

export type ProspectingObservation = {
  portal: string;
  listingKey: string;
  observedOn: string;
  price: number;
  boundLabel: string | null;
};

export type ProspectingRow = {
  id: string;
  title: string | null;
  // Adresse rendue par le Localisateur ; null tant qu'il n'en rend pas une seule.
  address: string | null;
  // Étiquette du Localisateur, affichée telle quelle.
  label: string | null;
  confirmed: boolean;
  // Mission 84 — le conseiller peut confirmer lui-même : l'adresse proposée attend son accord,
  // ou c'est déjà lui qui l'a confirmée ou saisie.
  canAcceptAddress: boolean;
  confirmedByAdvisor: boolean;
  price: number | null;
  surfaceArea: number | null;
  roomsCount: number | null;
  onlineSince: string | null;
  priceDrop: string | null;
  listingUrl: string | null;
  // Mission 98 — l'identité publiée de l'annonce (portail + numéro) : deux concurrents qui la
  // partagent sont le même bien ; le numéro se lit sur la tournée, pour appeler le confrère.
  listingKey: string | null;
  listingNumber: string | null;
  // Mission 98 — la date de la demande si l'adresse est sur la liste « Ne plus solliciter ».
  opposedOn: string | null;
  // Mission 105 — l'annonce a disparu depuis le rendez-vous (relecture des prix, sur preuve).
  goneSinceMeeting: boolean;
  // Mission 86 — ce que la carte de Prospection et le rapprochement acheteur lisent en plus :
  // le type et la commune de l'annonce, son portail, et où en est la prospection.
  propertyType: string | null;
  city: string | null;
  portal: string | null;
  status: ProspectingStatus;
  handedAt: string | null;
  meetingAt: string | null;
  mandateAt: string | null;
  declinedAt: string | null;
  // Mission 83 — à qui s'adresser (confrère, propriétaire, à vérifier), et les quatre valeurs
  // que le conseiller corrige d'un clic sur la ligne.
  step: ProspectingStep;
  mandate: {
    id: string;
    project_id: string;
    sold_by: string | null;
    sold_by_source: string | null;
    exclusivity: string | null;
    exclusivity_source: string | null;
  };
};

const frDate = (iso: string): string => {
  const date = new Date(iso);
  return Number.isNaN(date.getTime())
    ? iso
    : date.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' });
};

const days = (count: number): string => `${count} ${count > 1 ? 'jours' : 'jour'}`;

// Mêmes règles que l'historique d'une annonce (mission 47) : la source est nommée, une borne
// basse reste un texte, et une première observation dit « vue par ACM », jamais « en ligne ».
export function describeOnlineSince(age: ListingAge): string | null {
  if (!age) {
    return null;
  }
  if (age.kind === 'exact') {
    return `En ligne depuis le ${frDate(age.publishedAt)} · ${days(age.days)} — d’après ${age.source}`;
  }
  if (age.kind === 'lowerBound') {
    return `En ligne depuis ${age.label} (${age.source})`;
  }
  return `Vue par ACM depuis ${days(age.days)}`;
}

// La baisse validée par le conseiller d'abord ; sinon celle qu'ACM a constatée entre deux
// observations, avec ses deux dates. Une hausse n'est pas une baisse : rien.
function describePriceDrop(
  competitor: Comparable,
  observations: ProspectingObservation[],
): string | null {
  if (competitor.price_drop_amount != null && competitor.price_drop_amount > 0) {
    const percentage =
      competitor.price_drop_percentage != null && competitor.price_drop_percentage > 0
        ? ` (−${formatPercent(competitor.price_drop_percentage)})`
        : '';
    return `Baisse de ${formatEuro(competitor.price_drop_amount)}${percentage}`;
  }
  const change = derivePriceChange(
    observations.map((observation) => ({
      observedOn: observation.observedOn,
      price: observation.price,
    })),
  );
  if (!change || change.amount <= 0) {
    return null;
  }
  return `Baisse constatée par ACM : ${formatEuro(change.fromPrice)} le ${frDate(change.fromDate)}, ${formatEuro(change.toPrice)} le ${frDate(change.toDate)} (−${formatPercent(change.percentage)})`;
}

const clean = (value: string | null): string | null => value?.trim() || null;

export function buildProspectingRows(
  competitors: Comparable[],
  observations: ProspectingObservation[],
  now: Date = new Date(),
  oppositions: Oppositions = NO_OPPOSITIONS,
): ProspectingRow[] {
  return competitors
    .filter((competitor) => competitor.is_selected)
    .map((competitor) => {
      const identity = competitor.listing_url ? extractListingKey(competitor.listing_url) : null;
      const own = identity
        ? observations
            .filter(
              (observation) =>
                observation.portal === identity.portal &&
                observation.listingKey === identity.listingKey,
            )
            .sort((a, b) => a.observedOn.localeCompare(b.observedOn))
        : [];
      const boundLabel = [...own]
        .reverse()
        .find((observation) => observation.boundLabel)?.boundLabel;

      const age = deriveListingAge(
        {
          publishedAtExact: competitor.listing_published_at,
          lowerBoundLabel: boundLabel ?? null,
          source: identity
            ? (LISTING_PORTAL_LABELS[identity.portal] ?? identity.portal)
            : clean(competitor.source),
          firstObservedAt: own.length > 0 ? own[0].observedOn : null,
        },
        now,
      );

      const listingKey = identity ? `${identity.portal}:${identity.listingKey}` : null;

      return {
        id: competitor.id,
        title: clean(competitor.title),
        address: clean(competitor.locator_address),
        label: clean(competitor.locator_label),
        confirmed: competitor.locator_confirmed === true,
        canAcceptAddress: canAcceptProposedAddress(competitor),
        confirmedByAdvisor: confirmedByAdvisor(competitor),
        price: competitor.price > 0 ? competitor.price : null,
        surfaceArea: competitor.surface_area,
        roomsCount: competitor.rooms_count,
        onlineSince: describeOnlineSince(age),
        priceDrop: describePriceDrop(competitor, own),
        listingUrl: clean(competitor.listing_url),
        listingKey,
        listingNumber: identity?.listingKey ?? null,
        // Mission 102 — par l'adresse ou par l'annonce : l'opposition suit le bien.
        opposedOn: opposedOn({ address: competitor.locator_address, listingKey }, oppositions),
        goneSinceMeeting: competitor.listing_gone_at != null,
        propertyType: clean(competitor.property_type),
        // Mission 99 — « Paris 15e » sur la carte, la tournée et le rapprochement acquéreur.
        city: displayCommune(clean(competitor.city), competitor.postal_code),
        portal: identity
          ? (LISTING_PORTAL_LABELS[identity.portal] ?? identity.portal)
          : clean(competitor.source),
        status: prospectingStatus(
          competitor,
          competitor.locator_confirmed === true && clean(competitor.locator_address) != null,
        ),
        handedAt: competitor.prospecting_handed_at,
        meetingAt: competitor.prospecting_meeting_at,
        mandateAt: competitor.prospecting_mandate_at,
        declinedAt: competitor.prospecting_declined_at,
        step: prospectingStep(competitor),
        mandate: {
          id: competitor.id,
          project_id: competitor.project_id,
          sold_by: competitor.sold_by,
          sold_by_source: competitor.sold_by_source,
          exclusivity: competitor.exclusivity,
          exclusivity_source: competitor.exclusivity_source,
        },
      };
    });
}
