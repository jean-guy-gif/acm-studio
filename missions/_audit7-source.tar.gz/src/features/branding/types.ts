// Mission 55 — la charte résolue d'une agence. Les couleurs sont des #RRGGBB (ou null si
// non définies → défauts produit). Les logos sont des URL publiques prêtes à afficher.
export type AgencyBranding = {
  brand: string | null;
  brandDeep: string | null;
  brandSoft: string | null;
  brandDarker: string | null;
  brandDarkest: string | null;
  onBrandText: string | null;
  textContrastAdjusted: boolean;
  logoLightUrl: string | null;
  logoDarkUrl: string | null;
  // Mission 57 — la clé de la police retenue (parmi la liste embarquée), ou null → typo
  // produit. Et l'adresse du site, conservée mais jamais ouverte (option B).
  fontFamily: string | null;
  siteUrl: string | null;
  // Mission 84 — l'adresse postale et la carte professionnelle de l'agence, en pied des
  // dossiers de prospection ; null → la mention est omise.
  postalAddress: string | null;
  professionalCard: string | null;
  // Mission 102 — qui a délivré la carte (CCI ou préfecture), exigé avec elle pour imprimer un
  // courrier ; et la garantie financière, sinon « Ne peut recevoir aucun fonds ».
  professionalCardIssuer: string | null;
  financialGuarantee: string | null;
  // Mission 87 — le nom imprimé sur les documents ; null → le nom de l'agence.
  documentName: string | null;
  validatedAt: string | null;
};
