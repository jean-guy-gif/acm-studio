'use server';

import { revalidatePath } from 'next/cache';

import { IDENTITY_MANAGER_ONLY_MESSAGE } from '@/features/branding/constants';
import {
  agencyMentionsInputSchema,
  typographyInputSchema,
} from '@/features/branding/schemas/typography-input';
import { derivePalette, isValidHex } from '@/features/branding/services/palette';
import { requireManagerProfile } from '@/features/team/services/require-manager';
import type { Database } from '@/lib/supabase/database.types';
import { createServiceRoleClient } from '@/lib/supabase/service-role';

type ServiceClient = ReturnType<typeof createServiceRoleClient>;

export type SaveBrandingResult = { ok: true } | { ok: false; error: string };

type BrandingInsert = Database['public']['Tables']['agency_branding']['Insert'];

const BUCKET = 'agency-branding';
const ACCEPTED = new Map<string, string>([
  ['image/svg+xml', 'svg'],
  ['image/png', 'png'],
  ['image/jpeg', 'jpg'],
  ['image/webp', 'webp'],
]);

// Dépose un logo dans le bucket (client utilisateur → RLS : 1er segment = agency_id). Écrase
// la version précédente (chemin stable). Retourne le chemin, ou null si aucun fichier.
async function uploadLogo(
  supabase: ServiceClient,
  agencyId: string,
  variant: 'light' | 'dark',
  file: File | null,
): Promise<{ ok: true; path: string | null } | { ok: false; error: string }> {
  if (!file || file.size === 0) {
    return { ok: true, path: null };
  }
  const ext = ACCEPTED.get(file.type);
  if (!ext) {
    return { ok: false, error: 'Logo : formats acceptés SVG, PNG, WebP, JPEG.' };
  }
  const path = `${agencyId}/logo-${variant}.${ext}`;
  // On téléverse les OCTETS (Uint8Array), pas l'objet File : plus fiable côté serveur.
  const bytes = new Uint8Array(await file.arrayBuffer());
  const { error } = await supabase.storage
    .from(BUCKET)
    .upload(path, bytes, { upsert: true, contentType: file.type });
  if (error) {
    return { ok: false, error: 'Le dépôt du logo a échoué. Réessayez.' };
  }
  return { ok: true, path };
}

// Mission 55 jalon 1 — la charte, validée sur aperçu. Le navigateur ne fournit que la
// couleur PRIMAIRE et les fichiers de logo ; la palette est RE-DÉRIVÉE côté serveur (jamais
// on ne fait confiance à une palette venue du client), chaque couleur reste un #RRGGBB.
export async function saveBranding(formData: FormData): Promise<SaveBrandingResult> {
  // Mission 88 — l'identité de l'agence est vue par les vendeurs, et l'écriture passe par la
  // clé service : le garde est ICI. Seul un manager non retiré de l'agence la modifie.
  const guard = await requireManagerProfile();
  if (!guard.ok) {
    return { ok: false, error: IDENTITY_MANAGER_ONLY_MESSAGE };
  }
  const agencyId = guard.profile.agency_id;

  const rawPrimary = formData.get('primary_color');
  const primary = typeof rawPrimary === 'string' ? rawPrimary.trim().toLowerCase() : '';
  if (!isValidHex(primary)) {
    return { ok: false, error: 'Choisissez une couleur de marque valide (#RRGGBB).' };
  }
  const palette = derivePalette(primary);

  // Mission 57 — la police retenue (clé embarquée, ou null → défaut produit) et l'adresse du
  // site (conservée, jamais ouverte). Une clé hors liste ou une URL malformée est refusée.
  const typography = typographyInputSchema.safeParse({
    fontFamily: formData.get('font_family') ?? null,
    siteUrl: formData.get('site_url') ?? null,
  });
  if (!typography.success) {
    return { ok: false, error: 'Adresse du site invalide, ou police inconnue.' };
  }

  // Mission 84 — adresse postale et carte professionnelle, pour le pied des dossiers de
  // prospection. Facultatives ; un texte trop long est refusé.
  const mentions = agencyMentionsInputSchema.safeParse({
    postalAddress: formData.get('postal_address') ?? null,
    professionalCard: formData.get('professional_card') ?? null,
    professionalCardIssuer: formData.get('professional_card_issuer') ?? null,
    financialGuarantee: formData.get('financial_guarantee') ?? null,
    documentName: formData.get('document_name') ?? null,
  });
  if (!mentions.success) {
    return {
      ok: false,
      error:
        'Adresse, carte professionnelle, garantie financière ou nom sur les documents trop long.',
    };
  }

  // Écritures via le client SERVICE ROLE, APRÈS authentification : le chemin est imposé par
  // le serveur (agency_id de l'appelant), jamais fourni par le navigateur. La RLS du bucket
  // reste en défense pour tout accès direct.
  const serviceClient = createServiceRoleClient();
  const light = await uploadLogo(
    serviceClient,
    agencyId,
    'light',
    formData.get('logo_light') as File | null,
  );
  if (!light.ok) {
    return light;
  }
  const dark = await uploadLogo(
    serviceClient,
    agencyId,
    'dark',
    formData.get('logo_dark') as File | null,
  );
  if (!dark.ok) {
    return dark;
  }

  const now = new Date().toISOString();
  const row: BrandingInsert = {
    agency_id: agencyId,
    brand: palette.brand,
    brand_deep: palette.brandDeep,
    brand_soft: palette.brandSoft,
    brand_darker: palette.brandDarker,
    brand_darkest: palette.brandDarkest,
    on_brand_text: palette.onBrandText,
    text_contrast_adjusted: palette.textContrastAdjusted,
    font_family: typography.data.fontFamily,
    site_url: typography.data.siteUrl,
    postal_address: mentions.data.postalAddress,
    professional_card: mentions.data.professionalCard,
    professional_card_issuer: mentions.data.professionalCardIssuer,
    financial_guarantee: mentions.data.financialGuarantee,
    document_name: mentions.data.documentName,
    validated_at: now,
    updated_at: now,
    // Ne pas écraser un chemin de logo existant avec null si aucun fichier n'a été redéposé.
    ...(light.path ? { logo_light_path: light.path } : {}),
    ...(dark.path ? { logo_dark_path: dark.path } : {}),
  };

  const { error } = await serviceClient
    .from('agency_branding')
    .upsert(row, { onConflict: 'agency_id' });
  if (error) {
    return { ok: false, error: 'L’enregistrement de la charte a échoué. Réessayez.' };
  }

  // La charte s'applique à tout l'outil : on rafraîchit tout.
  revalidatePath('/', 'layout');
  return { ok: true };
}
