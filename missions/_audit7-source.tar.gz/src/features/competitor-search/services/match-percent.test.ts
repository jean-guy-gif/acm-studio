import { describe, expect, it } from 'vitest';

import { learnFromDecisions } from '@/features/competitor-search/services/learn-from-decisions';
import {
  MATCH_SUMMARY_LINE,
  gapLine,
  matchDetail,
  matchPercent,
  type MatchPlace,
} from '@/features/competitor-search/services/match-percent';
import type { ProximityReason } from '@/features/competitor-search/types';
import { rankCandidates } from '@/features/competitor-search/services/rank-candidates';
import {
  STREAM_ESTATE_LABEL,
  STREAM_ESTATE_SOURCE,
  type CompetitorCandidate,
  type CompetitorSearchCriteria,
  type GeoPoint,
} from '@/features/competitor-search/types';

// Mission 71 §4 — le % de correspondance, sur 100 points ; un critère inconnu sort du calcul.

const CRITERIA: CompetitorSearchCriteria = {
  city: 'Saint-Laurent-du-Var',
  postalCode: '06700',
  propertyType: 'apartment',
  district: null,
  surfaceArea: 70,
  roomsCount: 4,
  advisorPriceMin: 400000,
  advisorPriceMax: 450000,
};

const SUBJECT: GeoPoint = { lat: 43.6745, lon: 7.1875 };
const metersNorth = (m: number): GeoPoint => ({ lat: SUBJECT.lat + m / 111_320, lon: SUBJECT.lon });

function candidate(overrides: Partial<CompetitorCandidate> = {}): CompetitorCandidate {
  return {
    key: 'k',
    url: 'https://www.seloger.com/annonces/achat/appartement/k.htm',
    title: null,
    price: 420000,
    surfaceArea: 70,
    roomsCount: 4,
    propertyType: 'apartment',
    pricePerSqm: null,
    landArea: null,
    city: 'Saint-Laurent-du-Var',
    photoUrls: [],
    isNewBuild: false,
    ...overrides,
  };
}

const known = (criterion: string, points: number): ProximityReason => ({
  criterion,
  level: 1,
  label: criterion,
  points,
  known: true,
});

const place = (distanceMeters: number | null, sameCommune = true): MatchPlace => ({
  distanceMeters,
  sameCommune,
});

describe('matchPercent', () => {
  it('identique à moins de 500 m : 100 %', () => {
    expect(matchPercent(CRITERIA, candidate(), [], place(300))).toBe(100);
  });

  it('les tranches du secteur : 25, 20, 15, 8, 4 points', () => {
    const at = (m: number) => matchPercent(CRITERIA, candidate(), [], place(m));
    // Surface, prix et pièces identiques (55 points sur 55) + secteur sur 25.
    expect([at(400), at(900), at(1600), at(4000), at(9000)]).toEqual([100, 94, 88, 79, 74]);
  });

  it('sans position : même commune 15, commune voisine 5', () => {
    expect(matchPercent(CRITERIA, candidate(), [], place(null, true))).toBe(88);
    expect(matchPercent(CRITERIA, candidate(), [], place(null, false))).toBe(75);
  });

  it('plus grand de 12 %, une pièce de plus, prix 4 % hors fourchette, à 1,6 km', () => {
    const wider = candidate({ surfaceArea: 78.4, roomsCount: 5, price: 468000 });
    // 15 (secteur) + 8 (surface) + 10 (prix) + 7 (pièces) = 40 sur 80.
    expect(matchPercent(CRITERIA, wider, [], place(1600))).toBe(50);
  });

  it('un critère inconnu sort du calcul ; un critère connu qui ne rapproche pas compte 0', () => {
    const unknownSurface = candidate({ surfaceArea: null });
    expect(matchPercent(CRITERIA, unknownSurface, [], place(300))).toBe(100);
    // Stationnement connu et différent (0 sur 5), extérieur identique (5 sur 5) : 85 sur 90.
    const reasons = [known('parking', -1), known('outdoor', 1)];
    expect(matchPercent(CRITERIA, candidate(), reasons, place(300))).toBe(94);
    // Un critère « non indiqué » (known: false) ne pèse rien.
    const unknown = { ...known('parking', 0), known: false };
    expect(matchPercent(CRITERIA, candidate(), [unknown], place(300))).toBe(100);
  });

  it('Mission 80 — DPE sur 10 points : même classe 10, une classe d’écart 5, au-delà 0', () => {
    const subject = { ...CRITERIA, energyClass: 'D' as const };
    const at = (energyClass: 'D' | 'E' | 'C' | 'F') =>
      matchPercent(subject, candidate({ energyClass }), [], place(300));
    // Secteur, surface, prix et pièces identiques : 80 sur 80, plus le DPE sur 10.
    expect([at('D'), at('E'), at('C'), at('F')]).toEqual([100, 94, 94, 89]);
  });

  it('Mission 80 — DPE inconnu d’un côté ou de l’autre : hors calcul', () => {
    const subject = { ...CRITERIA, energyClass: 'D' as const };
    const wider = candidate({ surfaceArea: 78.4, roomsCount: 5, price: 468000 });
    // Sans DPE : 40 sur 80, comme avant la mission.
    expect(matchPercent(subject, wider, [], place(1600))).toBe(50);
    expect(matchPercent(subject, { ...wider, energyClass: null }, [], place(1600))).toBe(50);
    expect(matchPercent(CRITERIA, { ...wider, energyClass: 'G' }, [], place(1600))).toBe(50);
    // Avec les deux : 40 + 10 sur 90.
    expect(matchPercent(subject, { ...wider, energyClass: 'D' }, [], place(1600))).toBe(56);
  });

  it('niveau 2 : état, étage, ascenseur, année 2 ; piscine, exposition 1', () => {
    const reasons = ['condition', 'floor', 'elevator', 'year', 'pool', 'exposure'].map((c) =>
      known(c, -1),
    );
    // 80 + 0 sur 80 + 10.
    expect(matchPercent(CRITERIA, candidate(), reasons, place(300))).toBe(89);
  });
});

describe('gapLine', () => {
  it('rien pour un bien identique et localisé à moins de 1 km', () => {
    const located = candidate({ features: { ...FEATURES, location: SUBJECT } });
    expect(gapLine(CRITERIA, located, place(300))).toBeNull();
  });

  it('dit les critères réglés dont la donnée manque (mission 110)', () => {
    const unknown = candidate({
      features: { ...FEATURES, location: SUBJECT },
      streamEstate: {
        propertyId: 'p',
        originSite: 'SeLoger',
        onlineSince: null,
        lastSeenAt: null,
        priceDrops: [],
        criteriaUnknown: ['minFloor', 'pool'],
      },
    });
    expect(gapLine(CRITERIA, unknown, place(300))).toBe('Étage non indiqué · Piscine non indiquée');
  });

  it('dit chaque écart, dans l’ordre', () => {
    const wider = candidate({
      surfaceArea: 78.4,
      roomsCount: 5,
      price: 468000,
      features: { ...FEATURES, location: SUBJECT },
    });
    expect(gapLine(CRITERIA, wider, place(1600))).toBe(
      'Même ville, à 1,6 km · Plus grand : 78\u00A0m² (+12\u00A0%) · 5 pièces (+1) · Prix 4\u00A0% au-dessus de votre fourchette',
    );
  });

  it('commune voisine ; « Même ville — quartier non vérifié » sans position fiable', () => {
    const neighbour = candidate({ city: 'Cagnes-sur-Mer', features: { ...FEATURES } });
    expect(gapLine(CRITERIA, neighbour, place(null, false))).toBe(
      'Commune voisine : Cagnes-sur-Mer — quartier non vérifié',
    );
    const located = candidate({
      city: 'Cagnes-sur-Mer',
      features: { ...FEATURES, location: SUBJECT },
    });
    expect(gapLine(CRITERIA, located, place(6100, false))).toBe(
      'Commune voisine : Cagnes-sur-Mer, 6,1 km',
    );
    expect(gapLine(CRITERIA, candidate({ price: 385000 }), place(null))).toBe(
      'Même ville — quartier non vérifié · Prix 4\u00A0% en dessous de votre fourchette',
    );
  });

  it('sans position, même commune : 15 points de secteur dans le %', () => {
    // 15 + 20 + 20 + 15 = 70 sur 80.
    expect(matchPercent(CRITERIA, candidate(), [], place(null, true))).toBe(88);
  });
});

const FEATURES = {
  location: null,
  locationDiscarded: false,
  district: null,
  floor: null,
  hasElevator: null,
  hasPool: null,
  parking: null,
  outdoor: null,
  condition: null,
  exposure: null,
  constructionYear: null,
};

describe('l’ordre affiché suit le %', () => {
  it('un bien à 4 km ne passe jamais devant un bien identique à 300 m', () => {
    const stream = (key: string, location: GeoPoint, tier: 1 | 5) =>
      candidate({
        key,
        // Deux biens distincts : au même prix, ils n'en feraient qu'un (mission 78).
        price: tier === 1 ? 420000 : 421000,
        url: `https://www.seloger.com/annonces/achat/appartement/${key}.htm`,
        features: { ...FEATURES, location, parking: ['garage'] },
        streamEstate: {
          propertyId: key,
          originSite: 'SeLoger',
          onlineSince: null,
          lastSeenAt: null,
          priceDrops: [],
          inseeCode: '06123',
          tier,
        },
      });
    const near = stream('near', metersNorth(300), 1);
    // Plus loin, mais même stationnement que le bien vendeur (le niveau 1 l'aurait favorisé).
    const far = stream('far', metersNorth(4000), 5);
    const criteria = {
      ...CRITERIA,
      subject: {
        parkingTypes: ['garage'],
        outdoorSpaces: [],
        generalCondition: null,
        floor: null,
        hasElevator: null,
        hasPool: null,
        exposure: null,
        constructionYear: null,
      },
    };
    const search = rankCandidates(
      criteria,
      [
        {
          portal: STREAM_ESTATE_SOURCE,
          label: STREAM_ESTATE_LABEL,
          searchUrl: '',
          status: 'ok',
          message: null,
          candidates: [far, near],
        },
      ],
      learnFromDecisions([]),
      { subjectLocation: SUBJECT, subjectInseeCode: '06123' },
    );
    expect(search.ranked.map((entry) => [entry.candidate.key, entry.matchPercent])).toEqual([
      ['near', 100],
      ['far', 80], // 8 + 20 + 20 + 15 + 5 (même garage) = 68 sur 85
    ]);
    expect(search.ranked[1].gapLine).toBe('Même ville, à 4 km');
  });
});

// MISSION 78 — pièces libérées : la carte dit son écart, le classement revalide par cran.
describe('mission 78 : pièces libres', () => {
  const HOUSE: CompetitorSearchCriteria = {
    city: 'Cagnes-sur-Mer',
    postalCode: '06800',
    propertyType: 'house',
    district: null,
    surfaceArea: 200,
    roomsCount: 9,
    advisorPriceMin: 600000,
    advisorPriceMax: 750000,
  };
  const house = (
    key: string,
    tier: 1 | 3 | 5 | 6 | 7 | 8,
    over: Partial<CompetitorCandidate> = {},
  ) =>
    candidate({
      key,
      url: `https://www.seloger.com/annonces/achat/maison/${key}.htm`,
      propertyType: 'house',
      city: 'Cagnes-sur-Mer',
      price: 700000,
      surfaceArea: 201,
      roomsCount: 7,
      features: { ...FEATURES, location: SUBJECT },
      ...over,
      streamEstate: {
        propertyId: key,
        originSite: 'SeLoger',
        onlineSince: null,
        lastSeenAt: null,
        priceDrops: [],
        inseeCode: '06027',
        tier,
        ...over.streamEstate,
      },
    });
  const rank = (candidates: CompetitorCandidate[]) =>
    rankCandidates(
      HOUSE,
      [
        {
          portal: STREAM_ESTATE_SOURCE,
          label: STREAM_ESTATE_LABEL,
          searchUrl: '',
          status: 'ok',
          message: null,
          candidates,
        },
      ],
      learnFromDecisions([]),
      { subjectLocation: SUBJECT, subjectInseeCode: '06027' },
    );

  it('la carte dit « 7 pièces au lieu de 9 »', () => {
    expect(gapLine(HOUSE, house('a', 6), place(300))).toBe('7 pièces au lieu de 9');
    expect(gapLine(HOUSE, house('b', 6, { roomsCount: 1 }), place(300))).toBe(
      '1 pièce au lieu de 9',
    );
    expect(gapLine(HOUSE, house('c', 3, { roomsCount: 10 }), place(300))).toBe('10 pièces (+1)');
    expect(gapLine(HOUSE, house('d', 7, { roomsCount: null }), place(300))).toBe(
      'Nombre de pièces non indiqué',
    );
  });

  it('la carte dit « Annonce vue il y a N jours » au-delà de 7 jours', () => {
    const stale = house('a', 6, {
      roomsCount: 9,
      streamEstate: { staleOriginDays: 12 } as CompetitorCandidate['streamEstate'],
    });
    expect(gapLine(HOUSE, stale, place(300))).toBe('Annonce vue il y a 12 jours');
  });

  it('moins de pièces ou bien plus grand : admis aux crans 6 à 8, jamais aux crans 1 à 5', () => {
    const search = rank([
      house('freed', 6, { price: 700000 }),
      house('huge', 7, { price: 701000, surfaceArea: 320 }),
      house('roomless', 7, { price: 702000, roomsCount: null }),
      house('early', 5, { price: 703000 }), // 7 pièces à un cran qui exige 9 ou 10
      house('early-huge', 5, { price: 704000, roomsCount: 9, surfaceArea: 320 }),
      house('small', 6, { price: 705000, surfaceArea: 170 }), // jamais plus de 10 % plus petit
      house('pricey', 8, { price: 800000 }), // au-delà de ±5 % hors fourchette
    ]);
    expect(search.ranked.map((entry) => entry.candidate.key).sort()).toEqual([
      'freed',
      'huge',
      'roomless',
    ]);
    expect(search.ranked.find((entry) => entry.candidate.key === 'huge')?.gapLine).toBe(
      'Plus grand : 320\u00A0m² (+60\u00A0%) · 7 pièces au lieu de 9',
    );
    // Les pièces comptent dans le % : 7 au lieu de 9 perd les 15 points des pièces.
    expect(search.ranked.find((entry) => entry.candidate.key === 'freed')?.matchPercent).toBe(81);
  });

  it('appartement : aux crans 6 à 8, jamais moins de pièces que le bien vendeur', () => {
    const flat = { ...HOUSE, propertyType: 'apartment', roomsCount: 3, surfaceArea: 63 };
    const card = (key: string, price: number, roomsCount: number | null) =>
      house(key, 6, { propertyType: 'apartment', surfaceArea: 64, price, roomsCount });
    const search = rankCandidates(
      flat,
      [
        {
          portal: STREAM_ESTATE_SOURCE,
          label: STREAM_ESTATE_LABEL,
          searchUrl: '',
          status: 'ok',
          message: null,
          candidates: [
            card('two', 700000, 2),
            card('five', 701000, 5),
            card('roomless', 702000, null),
          ],
        },
      ],
      learnFromDecisions([]),
      { subjectLocation: SUBJECT, subjectInseeCode: '06027' },
    );
    expect(search.ranked.map((entry) => entry.candidate.key).sort()).toEqual(['five', 'roomless']);
    const line = (key: string) =>
      search.ranked.find((entry) => entry.candidate.key === key)?.gapLine;
    expect(line('five')).toBe('5 pièces au lieu de 3');
    expect(line('roomless')).toBe('Nombre de pièces non indiqué');
  });

  it('une commune voisine n’entre qu’à partir du cran 7', () => {
    const elsewhere = (key: string, tier: 6 | 7, price: number) =>
      house(key, tier, {
        price,
        city: 'Vence',
        streamEstate: { inseeCode: '06157' } as CompetitorCandidate['streamEstate'],
      });
    const search = rank([elsewhere('six', 6, 700000), elsewhere('seven', 7, 701000)]);
    expect(search.ranked.map((entry) => entry.candidate.key)).toEqual(['seven']);
  });

  it('le même bien sous deux identifiants n’est proposé qu’une fois', () => {
    const search = rank([
      house('a', 6, { price: 695000, surfaceArea: 189 }),
      house('b', 7, { price: 695000, surfaceArea: 189.35 }),
      house('c', 7, { price: 695000, surfaceArea: 195 }),
    ]);
    expect(search.ranked.map((entry) => entry.candidate.key).sort()).toEqual(['a', 'c']);
  });
});

// Mission 97 — le détail du % se lit sur le calcul existant (M71, M80), sans le changer.
describe('matchDetail — ce qui a pesé dans le %', () => {
  const plain = (text: string): string => text.replace(/[\u00a0\u202f]/g, ' ');
  const percentOf = (lines: { earned: number; possible: number }[]): number =>
    Math.round(
      (lines.reduce((sum, line) => sum + line.earned, 0) /
        lines.reduce((sum, line) => sum + line.possible, 0)) *
        100,
    );

  it('reprend le calcul : la somme des lignes redonne le même pourcentage', () => {
    const cases: [CompetitorCandidate, ProximityReason[], MatchPlace][] = [
      [candidate(), [], place(300)],
      [candidate({ surfaceArea: 78, price: 465000, roomsCount: 5 }), [], place(1600)],
      [candidate({ surfaceArea: null, price: 380000 }), [known('parking', 1)], place(null, true)],
      [
        candidate({ roomsCount: null }),
        [known('parking', 0), known('outdoor', 2), known('pool', 0)],
        place(null, false),
      ],
    ];
    for (const [competitor, reasons, where] of cases) {
      const detail = matchDetail(CRITERIA, competitor, reasons, where);
      expect(percentOf(detail)).toBe(matchPercent(CRITERIA, competitor, reasons, where));
    }
  });

  it('dit chaque critère compté, avec ses valeurs', () => {
    const detail = matchDetail(
      CRITERIA,
      candidate({ surfaceArea: 68.4, price: 465000 }),
      [],
      place(1600),
    );
    expect(detail.map((line) => `${line.label} : ${plain(line.text)} ${line.verdict}`)).toEqual([
      'Secteur : à 1,6 km partial',
      'Surface : 68 m² pour 70 m² full',
      'Prix : hors fourchette (+3 %) partial',
      'Pièces : 4 pièces pour 4 pièces full',
    ]);
  });

  it('un prix loin de la fourchette ne gagne aucun point : ✗', () => {
    const detail = matchDetail(CRITERIA, candidate({ price: 520000 }), [], place(300));
    expect(detail.find((line) => line.label === 'Prix')).toMatchObject({
      verdict: 'none',
      earned: 0,
    });
  });

  it('un critère inconnu sort du calcul, donc du détail', () => {
    const detail = matchDetail(
      CRITERIA,
      candidate({ surfaceArea: null, roomsCount: null }),
      [{ ...known('parking', 1), known: false }],
      place(300),
    );
    expect(detail.map((line) => line.label)).toEqual(['Secteur', 'Prix']);
  });

  it('les équipements reprennent le verdict de l’ordre (proximity)', () => {
    const detail = matchDetail(
      CRITERIA,
      candidate(),
      [
        { ...known('parking', 1), label: 'garage des deux côtés' },
        { ...known('elevator', 0), label: 'pas d’ascenseur' },
      ],
      place(300),
    );
    expect(detail.slice(-2)).toEqual([
      {
        label: 'Stationnement',
        text: 'garage des deux côtés',
        verdict: 'full',
        earned: 5,
        possible: 5,
      },
      { label: 'Ascenseur', text: 'pas d’ascenseur', verdict: 'none', earned: 0, possible: 2 },
    ]);
  });

  it('la ligne d’explication nomme ce que le % compare', () => {
    expect(MATCH_SUMMARY_LINE).toBe(
      'Ressemblance avec votre bien : secteur, surface, prix, pièces et équipements',
    );
  });

  it('chaque candidat classé porte son détail', () => {
    const search = rankCandidates(
      CRITERIA,
      [
        {
          portal: 'seloger',
          label: 'SeLoger',
          searchUrl: '',
          status: 'ok',
          message: null,
          candidates: [candidate()],
        },
      ],
      learnFromDecisions([]),
    );
    for (const entry of search.ranked) {
      expect(entry.matchDetail.length).toBeGreaterThan(0);
      expect(percentOf(entry.matchDetail)).toBe(entry.matchPercent);
    }
  });
});
