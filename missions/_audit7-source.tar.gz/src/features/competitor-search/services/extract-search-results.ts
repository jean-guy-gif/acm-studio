import type {
  CandidateFeatures,
  CompetitorCandidate,
  SearchExtraction,
  SearchPortal,
} from '@/features/competitor-search/types';
import { decodeHtmlEntities } from '@/features/comparable-import/utils/html-text';
import { isGenericImageUrl } from '@/features/comparable-import/utils/is-generic';
import { normalizeArea } from '@/features/comparable-import/utils/normalize-area';
import {
  normalizeCount,
  studioRoomsCount,
} from '@/features/comparable-import/utils/normalize-count';
import { normalizePrice } from '@/features/comparable-import/utils/normalize-price';
import { isNewBuildAddress } from '@/features/competitor-search/services/new-build';
import { normalizePropertyType } from '@/features/competitor-search/utils/normalize-property-type';

// MISSION 50 — lecture d'une page de RÉSULTATS de recherche.
//
// LA RÈGLE (§4) : on extrait par le MARQUEUR DE CARTE du portail, jamais par la
// forme de l'adresse. La leçon des jours précédents se vérifie ici : sur SeLoger,
// une des formes d'URL les plus fréquentes n'est pas une annonce mais un lien vers
// une commune voisine (« Achat appartements Saint-Laurent-du-Var (672 annonces) »).
// La page de Nice porte 33 conteneurs `id="classified-card-…"` pour 30 vraies
// cartes : 1 emplacement sponsorisé + 2 suggestions ne portent PAS le marqueur
// `serp-core-classified-card-testid`, et sortent d'eux-mêmes.
//
// La CLÉ vient de l'identifiant que le portail publie (id SeLoger, data-id Bien'ici,
// data-advertid Green Acres, id M&A), jamais d'une référence d'agence (mission 47 §3).
//
// Aucune donnée inventée : un champ absent de la carte reste null. Le contenu lu est
// une donnée, jamais une instruction : rien n'est exécuté ni réinjecté comme HTML.

// Taille de page fixe mesurée : SeLoger 30 · Bien'ici 26 · Green Acres 24 · M&A 17.
// La borne couvre la plus grande sans jamais tronquer une page réelle.
export const MAX_SEARCH_CANDIDATES = 60;

export function detectSearchPortal(hostname: string): SearchPortal | null {
  const host = hostname.toLowerCase().replace(/^www\./, '');
  if (host === 'green-acres.fr' || host.endsWith('.green-acres.fr')) {
    return 'green_acres';
  }
  if (host === 'seloger.com' || host.endsWith('.seloger.com') || host === 'selogerneuf.com') {
    return 'seloger';
  }
  if (host === 'bienici.com' || host.endsWith('.bienici.com')) {
    return 'bienici';
  }
  if (host === 'maisonsetappartements.fr' || host.endsWith('.maisonsetappartements.fr')) {
    return 'maisons_appartements';
  }
  return null;
}

// --- petits lecteurs, tous bornés à un chunk de carte déjà découpé -------------

function attr(tag: string, name: string): string | null {
  const match = tag.match(new RegExp(`${name}\\s*=\\s*"([^"]*)"`, 'i'));
  return match ? decodeHtmlEntities(match[1]) : null;
}

function firstGroup(input: string, regex: RegExp): string | null {
  const match = input.match(regex);
  return match ? decodeHtmlEntities(match[1]).trim() : null;
}

// Une fourchette de prix (« 670 000 à 770 000 € ») marque un programme neuf, pas un
// prix ferme. On la détecte AVANT de normaliser (normalizePrice collerait les deux
// nombres en un montant absurde puis renverrait null).
function looksLikePriceRange(text: string): boolean {
  return /\d[\d\s .]{2,}\s*(?:à|-|–)\s*\d[\d\s .]{2,}\s*(?:€|EUR)/i.test(decodeHtmlEntities(text));
}

function readPrice(text: string | null): number | null {
  if (text == null || looksLikePriceRange(text)) {
    return null;
  }
  const match = decodeHtmlEntities(text).match(/(\d[\d\s .,]{2,})\s*€/);
  return match ? normalizePrice(match[1]) : null;
}

function readSurface(text: string | null): number | null {
  if (text == null) {
    return null;
  }
  // Pas de \b après « m² » : « ² » n'est pas un caractère de mot, donc « 41 m², »
  // ne ferait jamais frontière. Un lookahead « pas une lettre » suffit et évite de
  // confondre avec « m2aa ».
  const match = decodeHtmlEntities(text).match(/(\d{1,4}(?:[.,]\d{1,2})?)\s*m(?:²|2)(?![a-z])/i);
  return match ? normalizeArea(match[1]) : null;
}

// Mission 70 — surface du TERRAIN telle que la carte l'écrit (« 800 m² de terrain », « 5 300 m²
// de terrain »). Jamais confondue avec la surface habitable : on n'accepte qu'un nombre suivi de
// « m² de terrain ». Rien n'est cherché dans une description libre.
function readLandArea(text: string | null): number | null {
  if (text == null) {
    return null;
  }
  const match = decodeHtmlEntities(text).match(
    /(\d{1,3}(?:[\s  ]\d{3})*(?:[.,]\d{1,2})?)\s*m(?:²|2)\s+de\s+terrain/i,
  );
  return match ? normalizeArea(match[1].replace(/[\s  ]/g, '')) : null;
}

// Prix au m² tel que le portail l'AFFICHE, jamais recalculé (§ « aucune donnée
// inventée »). Bien'ici abrège les gros montants : « 11k €/m² », « 17,4k €/m² ».
function readPricePerSqm(text: string | null): number | null {
  if (text == null) {
    return null;
  }
  const decoded = decodeHtmlEntities(text);
  const abbreviated = decoded.match(/(\d+(?:[.,]\d+)?)\s*k\s*€/i);
  if (abbreviated) {
    return Math.round(Number.parseFloat(abbreviated[1].replace(',', '.')) * 1000);
  }
  return readPrice(text);
}

function readRooms(text: string | null): number | null {
  if (text == null) {
    return null;
  }
  const decoded = decodeHtmlEntities(text);
  const match = decoded.match(/(\d{1,2})\s*pi[eè]ces?\b/i);
  if (match) {
    return normalizeCount(match[1]);
  }
  // Mission 68 — une carte qui dit « Studio », « T1 » ou « F1 » sans « N pièces » (l'étiquette
  // « Pièces : Studio » de Green Acres) compte pour 1 pièce. Sans cela elle était écartée
  // « faute de nombre de pièces » alors que la carte le dit.
  return studioRoomsCount(decoded);
}

// Un LOGO D'AGENCE n'est pas la photo du bien (même famille que l'habillage écarté
// en mission 49). Deux familles de signaux, MESURÉES :
//  - le balisage/chemin : « Logo de l'annonceur », account-logo, /Agences/, /logos/… ;
//  - la TAILLE : chez SeLoger le logo n'a AUCUN de ces mots — c'est juste la première
//    image de la carte, minuscule (h=50), sur le même CDN que les photos, avec le nom
//    de l'agence en alt (« CABINET IMMOBILIER NICE »). La vraie photo fait w=626. Une
//    image dont une dimension déclarée est ≤ 160 px est une vignette/logo, pas la
//    photo du bien (les vrais logos Bien'ici font height=90 ; les photos ≥ 180).
function isAgencyLogo(imgTag: string, src: string): boolean {
  if (/logo|annonceur|agen(?:ce|cy)|publisher/i.test(imgTag)) {
    return true;
  }
  if (/\/agences?\/|\/logos?\/|[/_-]logo[._/-]|\/publisher/i.test(src)) {
    return true;
  }
  for (const match of src.matchAll(/[?&](?:w|h|width|height)=(\d{1,4})\b/gi)) {
    if (Number.parseInt(match[1], 10) <= 160) {
      return true;
    }
  }
  return false;
}

const IMG_URL_ATTRS = ['data-src', 'data-lazy-src', 'data-original', 'data-thumb-src', 'src'];

function imgTagSrc(tag: string): string | null {
  for (const name of IMG_URL_ATTRS) {
    const match = tag.match(new RegExp(`${name}\\s*=\\s*"([^"]+)"`, 'i'));
    if (match) {
      return decodeHtmlEntities(match[1]);
    }
  }
  return null;
}

// TOUTES les VRAIES photos du bien portées par la carte, dans l'ordre : on parcourt
// les <img>, on saute les logos d'agence, l'habillage générique et les vignettes/icônes
// (dimension déclarée ≤ 160 px), on résout en absolu et on déduplique les URLs
// identiques. On ne va JAMAIS chercher la galerie complète sur la page d'annonce — ce
// serait une fenêtre par candidat, exactement ce qu'on évite. Ce qui est sur la carte
// suffit. Liste vide si aucune vraie photo (jamais un logo par défaut).
function cardPhotos(chunk: string, baseUrl: string): string[] {
  const urls: string[] = [];
  const seen = new Set<string>();
  for (const tag of chunk.match(/<img\b[^>]*>/gi) ?? []) {
    const src = imgTagSrc(tag);
    if (src == null || isGenericImageUrl(src) || isAgencyLogo(tag, src)) {
      continue;
    }
    try {
      const url = new URL(src, baseUrl);
      if (url.protocol !== 'http:' && url.protocol !== 'https:') {
        continue;
      }
      const absolute = url.toString();
      if (!seen.has(absolute)) {
        seen.add(absolute);
        urls.push(absolute);
      }
    } catch {
      // URL de photo invalide : ignorée.
    }
  }
  return urls;
}

// Adresse absolue d'une annonce. Le fragment (ancre d'UI) part TOUJOURS. La query, elle,
// n'est gardée que pour les paramètres qui PORTENT l'identifiant publié de l'annonce :
//   - SeLoger, Bien'ici, Green Acres publient l'identifiant dans le CHEMIN → rien à garder.
//     Leur query n'est que du contexte de recherche, et le robots.txt du portail peut refuser
//     ces formes d'adresse (cf. comparable-import/normalize-listing-url) — on la retire.
//   - Maisons & Appartements publie l'identifiant dans la query (ficheAnnonce.php?…&IdAnnonce=…)
//     → on garde IdAnnonce. Sans lui, les 17 cartes retombaient sur la même adresse et 16
//     passaient pour des doublons (mission 61 §2-C).
// On ne garde que les paramètres demandés, jamais toute la query : l'adresse reste minimale et
// déterministe, comme la normalisation de l'import.
function absolute(
  href: string | null,
  baseUrl: string,
  keepQueryParams: readonly string[] = [],
): string | null {
  if (href == null || href.trim() === '') {
    return null;
  }
  try {
    const url = new URL(href, baseUrl);
    url.hash = '';
    const keep = new Set(keepQueryParams);
    const kept = [...url.searchParams.entries()].filter(([name]) => keep.has(name));
    url.search = '';
    for (const [name, value] of kept) {
      url.searchParams.append(name, value);
    }
    return url.toString();
  } catch {
    return null;
  }
}

// Décode un base64 (l'adresse Green Acres de data-o) SANS dépendre de l'environnement :
// l'extraction tourne désormais dans le navigateur (lecture par l'extension) comme
// côté serveur. `atob` existe des deux côtés ; l'adresse est de l'ASCII (une URL).
function decodeBase64(value: string): string {
  try {
    if (typeof atob === 'function') {
      return atob(value);
    }
    return Buffer.from(value, 'base64').toString('binary');
  } catch {
    return '';
  }
}

function titleCaseCity(value: string | null): string | null {
  if (value == null) {
    return null;
  }
  const cleaned = value.replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim();
  if (cleaned === '' || /\d/.test(cleaned)) {
    return null;
  }
  return cleaned.replace(/\b\p{L}/gu, (c) => c.toUpperCase());
}

// Le type NOMMÉ EN PREMIER dans un texte libre, mot à mot : « maison individuelle divisée en 2
// appartements » est une maison. normalizePropertyType, lui, teste les catégories dans un ordre
// fixe (appartement d'abord) — juste pour un libellé court, pas pour une phrase.
function firstTypeInText(text: string | null): string | null {
  if (text == null) {
    return null;
  }
  for (const word of decodeHtmlEntities(text).split(/[^\p{L}]+/u)) {
    const type = word === '' ? null : normalizePropertyType(word);
    if (type != null) {
      return type;
    }
  }
  return null;
}

// Étape 2 — ce qu'une carte de portail dit en champs structurés pour l'ORDRE : le quartier ÉCRIT
// (jamais deviné d'une adresse) et l'étage SeLoger. Le reste (équipements, position) n'est pas sur
// la carte : inconnu, donc neutre.
function cardFeatures(district: string | null, floor: number | null): CandidateFeatures {
  return {
    location: null,
    locationDiscarded: false,
    district,
    floor,
    hasElevator: null,
    hasPool: null,
    parking: null,
    outdoor: null,
    condition: null,
    exposure: null,
    constructionYear: null,
  };
}

// SeLoger : « Le Port, Nice (06300) » → « Le Port ». Le quartier précède la commune ; sans virgule,
// la ligne ne nomme que la commune → pas de quartier.
function selogerDistrict(address: string | null): string | null {
  if (address == null) return null;
  const match = address.match(/^(.+?),\s*[^,]+$/);
  const district = match?.[1].trim() ?? '';
  return district === '' ? null : district;
}

// SeLoger, dans le titre : « …, 41 m², Étage 1/3 » → 1 ; « …, RDC/2 » → 0.
function selogerFloor(title: string | null): number | null {
  const text = decodeHtmlEntities(title ?? '');
  if (/,\s*RDC\b/i.test(text)) return 0;
  const match = text.match(/,\s*[ÉE]tage\s+(\d{1,2})\b/i);
  return match ? Number(match[1]) : null;
}

// Bien'ici : « 06000 Nice (Valrose) » → « Valrose ».
function bieniciDistrict(address: string | null): string | null {
  const match = decodeHtmlEntities(address ?? '').match(/\(([^)]+)\)\s*$/);
  const district = match?.[1].trim() ?? '';
  return district === '' ? null : district;
}

// --- découpage en cartes, par marqueur, portail par portail --------------------

type CardChunk = { key: string | null; chunk: string };

// Plafond de fenêtre d'une carte : borne la dernière carte (sans borne suivante) pour
// qu'elle n'avale pas le pied de page. Large devant une carte réelle (< 6 000 car.).
const CARD_MAX_CHARS = 16000;

// Découpe le document en fenêtres [début d'une carte, début de la suivante], selon
// des BORNES portées par le marqueur du portail. On ne lit jamais au-delà de la
// carte suivante : le contenu d'une carte ne déborde pas sur sa voisine.
function splitByBoundaries(
  html: string,
  boundary: RegExp,
  keyIndex: number,
  keep?: (openingChunk: string) => boolean,
): CardChunk[] {
  const marks: { index: number; key: string | null }[] = [];
  boundary.lastIndex = 0;
  let match: RegExpExecArray | null;
  while ((match = boundary.exec(html)) !== null) {
    marks.push({ index: match.index, key: match[keyIndex] ?? null });
  }
  const cards: CardChunk[] = [];
  for (let i = 0; i < marks.length; i += 1) {
    const start = marks[i].index;
    // La DERNIÈRE carte n'a pas de borne suivante : sans plafond, sa fenêtre avalerait
    // tout le pied de page (et ses images promo passeraient pour des photos du bien).
    // Une carte réelle fait < 6 000 caractères ; on borne à 16 000, ce qui ne tronque
    // aucune carte mais empêche la dernière de déborder.
    const next = i + 1 < marks.length ? marks[i + 1].index : html.length;
    const end = Math.min(next, start + CARD_MAX_CHARS);
    const chunk = html.slice(start, end);
    if (keep && !keep(chunk.slice(0, 300))) {
      continue;
    }
    cards.push({ key: marks[i].key, chunk });
  }
  return cards;
}

// --- lecteurs de carte par portail ---------------------------------------------

function readSelogerCard({ key, chunk }: CardChunk, pageUrl: string): CompetitorCandidate {
  const link = chunk.match(/<a\b[^>]*card-mfe-covering-link-testid[^>]*>/i)?.[0] ?? '';
  const href = attr(link, 'href');
  const title = attr(link, 'title');
  const url = absolute(href, pageUrl) ?? pageUrl;
  // Le titre porte tout : « Appartement à vendre - Nice - 249 000 € - 2 pièces, 41 m², Étage 1/3 ».
  // Le neuf y ajoute un SEGMENT « neuf » (« Appartement à vendre - neuf - Nice - … ») : c'est ce
  // segment qui le marque (jamais le mot « neuf » ailleurs dans le titre), et la commune vient
  // après lui.
  const allParts = (title ?? '').split(/\s+-\s+/);
  const newBuildSegment = allParts.some((part) => /^neu(?:f|ve)s?$/i.test(part.trim()));
  const parts = allParts.filter((part) => !/^neu(?:f|ve)s?$/i.test(part.trim()));
  const city = titleCaseCity(parts[1] ?? null);
  const priceText = title;
  const isNewBuild = newBuildSegment || isNewBuildAddress(url) || looksLikePriceRange(title ?? '');
  return {
    key,
    url,
    title: title ?? null,
    price: readPrice(priceText),
    surfaceArea: readSurface(title),
    roomsCount: readRooms(title),
    propertyType: normalizePropertyType(title),
    pricePerSqm: null,
    // « …, 140 m², 800 m² de terrain » : le titre porte le terrain après l'habitable.
    landArea: readLandArea(title),
    city,
    photoUrls: cardPhotos(chunk, pageUrl),
    isNewBuild,
    features: cardFeatures(
      selogerDistrict(firstGroup(chunk, /cardmfe-description-box-address"[^>]*>([^<]+)/i)),
      selogerFloor(title),
    ),
  };
}

function readBieniciCard({ key, chunk }: CardChunk, pageUrl: string): CompetitorCandidate {
  const href =
    firstGroup(chunk, /class="[^"]*detailedSheetLink[^"]*"[^>]*href="([^"]+)"/i) ??
    firstGroup(chunk, /href="([^"]*\/annonce\/[^"]+)"/i);
  const url = absolute(href, pageUrl) ?? pageUrl;
  const priceText = firstGroup(chunk, /ad-price__the-price"[^>]*>([^<]+)/i);
  const alt = firstGroup(chunk, /<img[^>]*\balt="([^"]+)"/i);
  // Ville lue sur le chemin de l'annonce : /annonce/vente/<ville>/… .
  const city = titleCaseCity(href?.match(/\/annonce\/[a-z]+\/([a-z0-9'’-]+)\//i)?.[1] ?? null);
  const isNewBuild = isNewBuildAddress(url) || looksLikePriceRange(priceText ?? '');
  return {
    key,
    url,
    title: alt,
    price: readPrice(priceText),
    surfaceArea: readSurface(alt),
    roomsCount: readRooms(alt),
    // Type sur le chemin de l'annonce (/annonce/vente/<ville>/<type>/…) ou dans l'alt.
    propertyType:
      normalizePropertyType(
        href?.match(/\/annonce\/[a-z]+\/[a-z0-9'’-]+\/([a-z-]+)\//i)?.[1] ?? null,
      ) ?? normalizePropertyType(alt),
    pricePerSqm: readPricePerSqm(
      firstGroup(chunk, /ad-price__price-per-square-meter"[^>]*>([^<]+)/i),
    ),
    // Mission 70 — la carte Bien'ici n'affiche pas le terrain ; rien n'est déduit de la description.
    landArea: null,
    city,
    photoUrls: cardPhotos(chunk, pageUrl),
    isNewBuild,
    features: cardFeatures(
      bieniciDistrict(
        firstGroup(chunk, /(?:real-estate-main-info__address|detailsAddress)[^"]*"[^>]*>([^<]+)/i),
      ),
      null,
    ),
  };
}

function readGreenAcresCard({ key, chunk }: CardChunk, pageUrl: string): CompetitorCandidate {
  // L'adresse de l'annonce est publiée PAR LE PORTAIL, encodée en base64 dans data-o
  // (ce n'est pas la deviner — §9 : « ne reconstruis pas l'adresse en devinant »).
  const dataO = chunk.match(/data-o="([A-Za-z0-9+/=]+)"/)?.[1] ?? '';
  let url = pageUrl;
  if (dataO) {
    try {
      const decoded = decodeBase64(dataO);
      url = absolute(decoded, pageUrl) ?? pageUrl;
    } catch {
      // data-o illisible : on garde la clé, l'URL reste celle de la page.
    }
  }
  // Les info-tags portent surface / pièces / prix au m².
  const tags = new Map<string, string>();
  for (const m of chunk.matchAll(/info-tag[^>]*title="([^"]*)"[^>]*>([\s\S]*?)<\/div>/gi)) {
    tags.set(decodeHtmlEntities(m[1]).toLowerCase(), m[2].replace(/<[^>]+>/g, ' '));
  }
  const localisation = firstGroup(chunk, /announce-localisation"[^>]*>([^<]+)/i);
  const city = titleCaseCity(localisation?.split('(')[0] ?? null);
  // Mission 70 — sur une recherche de maisons, Green Acres écrit /properties/immobilier/… : le
  // chemin ne dit plus le type. Le type se lit alors sur la CARTE, dans son titre (attribut title
  // du bloc announce-info : « Villa 4Ch - Vue Dégagée », « Maison À Vendre »). Quand le chemin
  // nomme un vrai type (/properties/appartement/…), il reste prioritaire : le titre est un texte
  // libre, et lu en premier il ferait d'« élégant 4 pièces… cave et garage » un parking.
  const cardTitle = firstGroup(chunk, /announce-info"[^>]*\btitle="([^"]*)"/i);
  const typeSegment = url.match(/\/properties\/([a-z-]+)\//i)?.[1] ?? null;
  const segmentType = normalizePropertyType(typeSegment);
  const propertyType = segmentType ?? firstTypeInText(cardTitle);
  // Libellé : composé du segment et de la commune, comme avant (« Appartement à Nice », « Neuf à
  // Nice ») ; avec le segment générique « immobilier », le titre de la carte (jamais « Immobilier
  // à … »).
  const typeLabel =
    typeSegment && typeSegment.toLowerCase() !== 'immobilier' ? titleCaseCity(typeSegment) : null;
  const title = typeLabel
    ? city
      ? `${typeLabel} à ${city}`
      : typeLabel
    : cardTitle && cardTitle !== ''
      ? cardTitle
      : null;
  return {
    key,
    url,
    title,
    price: readPrice(firstGroup(chunk, /info-price"[^>]*>([^<]+)/i)),
    surfaceArea: readSurface(tags.get('surface habitable') ?? null),
    roomsCount: readRooms(tags.get('pièces') ?? tags.get('pieces') ?? null),
    propertyType,
    pricePerSqm: readPricePerSqm(tags.get('prix par m²') ?? tags.get('prix par m2') ?? null),
    // Étiquette « Terrain » de la carte : « 488 m² de terrain ».
    landArea: readLandArea(tags.get('terrain') ?? null),
    city,
    photoUrls: cardPhotos(chunk, pageUrl),
    // Le neuf a son segment d'adresse : /properties/neuf/<commune>/… .
    isNewBuild: isNewBuildAddress(url),
  };
}

function readMaisonsCard({ key, chunk }: CardChunk, pageUrl: string): CompetitorCandidate {
  const href = firstGroup(chunk, /href="([^"]*ficheAnnonce[^"]*)"/i);
  // M&A publie l'identifiant dans la query (IdAnnonce) : on le garde, sinon les 17 cartes
  // retombent sur la même adresse ficheAnnonce.php (mission 61 §2-C). L'adresse ouvre la
  // bonne fiche et l'import (comparable-import) la lit par son HTML, pas par la forme de l'URL.
  const url = absolute(href, pageUrl, ['IdAnnonce']) ?? pageUrl;
  const alt = firstGroup(chunk, /<img[^>]*\balt="([^"]+)"/i);
  // Mission 65 — la commune est ÉCRITE sur la carte (« 77 m² Nice Réf : … », balise RR_ville_text) ;
  // l'alt la répète (« Appartement à vendre à St-Laurent-du-Var  - 4 pièces 77 m² »). L'ancienne
  // lecture (`\bà` sur l'alt) ne trouvait JAMAIS rien — « à » n'est pas un caractère de mot — et
  // M&A complète ses résultats avec des communes voisines : sans commune lue, une annonce de
  // Saint-Laurent-du-Var passait pour une annonce de Nice.
  const city = titleCaseCity(
    firstGroup(chunk, /class="[^"]*\bRR_ville_text\b[^"]*"[^>]*>([^<]+)/i) ??
      alt?.match(/vendre\s+à\s+(.+?)\s+-\s+\d/i)?.[1] ??
      null,
  );
  return {
    key,
    url,
    title: alt,
    price: readPrice(firstGroup(chunk, /RR_prix[^"]*"[^>]*>([^<]+)/i)),
    surfaceArea: readSurface(alt),
    roomsCount: readRooms(alt) ?? readRooms(firstGroup(chunk, /data-room="([^"]+)"/i)),
    propertyType: normalizePropertyType(alt),
    pricePerSqm: null,
    // Mission 70 — la carte M&A n'affiche pas le terrain ; rien n'est déduit de la description.
    landArea: null,
    city,
    photoUrls: cardPhotos(chunk, pageUrl),
    // Le libellé de carte que M&A génère pour le neuf : « Immobilier neuf - Appartement à vendre… ».
    isNewBuild: /^\s*immobilier\s+neu(?:f|ve)s?\s+-/i.test(alt ?? ''),
  };
}

const READERS: Record<
  SearchPortal,
  {
    split: (html: string) => CardChunk[];
    read: (card: CardChunk, pageUrl: string) => CompetitorCandidate;
  }
> = {
  seloger: {
    // Borne = chaque conteneur `id="classified-card-…"` ; on ne garde que ceux qui
    // portent le marqueur de vraie carte (ni sponsorisé, ni suggestion).
    split: (html) =>
      splitByBoundaries(html, /id="classified-card-([A-Z0-9]+)"/g, 1, (open) =>
        open.includes('serp-core-classified-card-testid'),
      ),
    read: readSelogerCard,
  },
  bienici: {
    split: (html) => splitByBoundaries(html, /<article\b[^>]*\bdata-id="([^"]+)"/g, 1),
    read: readBieniciCard,
  },
  green_acres: {
    // Seul le conteneur de carte porte data-advertid ET data-o côte à côte ; les
    // boutons « favoris/masquer » portent data-advertid seul.
    split: (html) =>
      splitByBoundaries(html, /data-advertid="([^"]+)"\s+data-o="[A-Za-z0-9+/=]+"/g, 1),
    read: readGreenAcresCard,
  },
  maisons_appartements: {
    // Mission 70 — la carte porte le type schema.org du bien : Apartment sur une recherche
    // d'appartements, House sur une recherche de maisons (SingleFamilyResidence en est la
    // variante schema.org). N'accepter qu'Apartment rendait la page maison vide (0 carte).
    split: (html) =>
      splitByBoundaries(
        html,
        /<article\b[^>]*\bid="(\d+)"[^>]*itemtype="https?:\/\/schema\.org\/(?:Apartment|House|SingleFamilyResidence)"/g,
        1,
      ),
    read: readMaisonsCard,
  },
};

// Lit TOUTES les cartes de la page, par marqueur. Le nombre renvoyé est le nombre de
// cartes réelles (30 · 26 · 24 · 17) — le compte du neuf et la déduplication sont
// une étape séparée (filterAndDedupeCandidates), pour que « cartes lues » reste
// vérifiable indépendamment de ce qu'on retient.
export function extractSearchResults(
  html: string,
  pageUrl: string,
  portal: SearchPortal,
  max: number = MAX_SEARCH_CANDIDATES,
): CompetitorCandidate[] {
  const reader = READERS[portal];
  const cards = reader.split(html).slice(0, max);
  return cards.map((card) => reader.read(card, pageUrl));
}

// Compte le neuf puis déduplique par IDENTITÉ PUBLIÉE (mission 61 §2-C) : la clé de
// l'annonce quand le portail en publie une (id SeLoger, data-id Bien'ici, data-advertid Green
// Acres, IdAnnonce M&A), l'adresse sinon. Première occurrence gardée, écartées comptées.
//
// On NE déduplique PLUS par ressemblance prix|surface|pièces|commune (§4) : deux biens distincts
// peuvent la partager, et on préfère afficher deux fois que masquer un vrai concurrent. On ne
// déduplique PAS non plus par la seule URL : tant que absolute() vidait la query, les 17 cartes
// M&A retombaient sur la même adresse et 16 passaient pour des doublons. La clé publiée, elle,
// reste distincte même quand l'adresse ne l'est pas. Cette fonction reçoit les cartes d'UN
// portail : la clé y suffit pour l'identité (le portail est implicite).
//
// Le neuf n'est plus écarté ICI (règle de Laurent, 05/10) : il est gardé, marqué `isNewBuild`, et
// c'est le classement qui le tient en réserve — il n'apparaît qu'en complément, sous 3 concurrents
// admis dans l'ancien après le desserrage complet (rankCandidates).
export function filterAndDedupeCandidates(candidates: CompetitorCandidate[]): SearchExtraction {
  let newBuild = 0;
  let excludedDuplicates = 0;
  const kept: CompetitorCandidate[] = [];
  const seen = new Set<string>();

  for (const candidate of candidates) {
    const identity = candidate.key ?? candidate.url;
    if (seen.has(identity)) {
      excludedDuplicates += 1;
      continue;
    }
    seen.add(identity);
    if (candidate.isNewBuild) newBuild += 1;
    kept.push(candidate);
  }

  return { candidates: kept, newBuild, excludedDuplicates };
}
